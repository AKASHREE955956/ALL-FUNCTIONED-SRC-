# 🤖 Save Restricted Content Bot v3.0

**Single-file bot** — everything in `main.py`

## 🚀 Run

```bash
cd bot
pip install -r requirements.txt
python main.py
```

## How It Works

1. `/start` → Main menu with all buttons
2. 🔐 LOGIN → Phone OTP or session string
3. 📤 Set Destination → Your channel
4. Send a `t.me` link → Bot asks quantity → Downloads & forwards

## Caption Rules (working!)

- 🔄 Replace Word → Bot asks find word → then replacement
- ❌ Delete Word → Bot asks word → auto-deletes from captions
- 🔹 Prefix / 🔸 Suffix → Added to every caption
- ⚙️ Settings → Shows all rules with ❌ delete buttons for each

## Files

```
bot/
├── main.py           ← Run this! Single file, everything included
├── requirements.txt
├── bot_settings.json ← Auto-created (user settings)
├── bot_sessions.json ← Auto-created (encrypted sessions)
├── bot_premium.json  ← Auto-created (premium users)
├── bot_admin_cfg.json← Auto-created (admin config)
└── bot_promos.json   ← Auto-created (promo codes)
```

## Config

Edit the top of `main.py`:

```python
API_ID    = 27094603
API_HASH  = "your_hash"
BOT_TOKEN = "your_token"
OWNER_ID  = 987260932
```
