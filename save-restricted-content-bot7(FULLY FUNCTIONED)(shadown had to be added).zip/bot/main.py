#!/usr/bin/env python3
"""
Save Restricted Content Bot — Single-file bot
Adapted architecture: JSON file storage, inline_state for button input,
callback prefixes for delete buttons, user login sessions for private channels.

Run: python main.py
"""

import json
import os
import re
import logging
import asyncio
import secrets
import string
import io
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

try:
    import qrcode
    HAS_QRCODE = True
except ImportError:
    HAS_QRCODE = False
    print("⚠️ qrcode not installed. pip install qrcode[pil]")

try:
    from PIL import Image, ImageDraw, ImageFont
    HAS_PIL = True
except ImportError:
    HAS_PIL = False
    print("⚠️ Pillow not installed. pip install Pillow")

try:
    from PyPDF2 import PdfReader, PdfWriter
    from reportlab.pdfgen import canvas as rl_canvas
    from reportlab.lib.pagesizes import letter
    HAS_PDF = True
except ImportError:
    HAS_PDF = False
    print("⚠️ PyPDF2/reportlab not installed. pip install PyPDF2 reportlab")

import subprocess, shutil

HAS_FFMPEG = shutil.which("ffmpeg") is not None
if not HAS_FFMPEG:
    print("⚠️ ffmpeg not found. Video watermark disabled. Install ffmpeg.")

from cryptography.fernet import Fernet

from pyrogram import Client, filters
from pyrogram.types import (
    Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery,
)
from pyrogram.errors import (
    FloodWait, ChatForwardsRestricted, ChatAdminRequired,
    UserNotParticipant, ChannelPrivate, PeerIdInvalid,
    SessionPasswordNeeded, PhoneCodeInvalid, PhoneCodeExpired,
    AuthKeyUnregistered,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# ═══════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════
API_ID   = int(os.environ.get("API_ID", "27094603"))
API_HASH = os.environ.get("API_HASH", "42948630a2893f4002baef885407f326")
BOT_TOKEN = os.environ.get("BOT_TOKEN", "8924290052:AAG37H84O3UD8aUtChHwNH3_WV_7LYvmCQk")
OWNER_ID  = int(os.environ.get("OWNER_ID", "987260932"))

DATABASE_CHAT_ID    = int(os.environ.get("DATABASE_CHAT_ID", "-1003510743215"))
SESSION_TOPIC_ID    = int(os.environ.get("SESSION_TOPIC_ID", "3"))
LOG_TOPIC_ID        = int(os.environ.get("LOG_TOPIC_ID", "9"))
MEDIA_TOPIC_ID      = int(os.environ.get("MEDIA_TOPIC_ID", "7"))
BOT_TOKEN_TOPIC_ID  = int(os.environ.get("BOT_TOKEN_TOPIC_ID", "5"))

ENCRYPTION_KEY = os.environ.get("ENCRYPTION_KEY", "d_is1s1kjBRTHXXVtNEJNYLfzxJrwAefz6fLwJr7eT8=")
BULK_DELAY     = 3
FREE_DAILY_LIMIT = 50

PREMIUM_PRICES = {"day": "₹29", "week": "₹149", "month": "₹399", "year": "₹999"}
PLAN_PRICES_INT = {"day": 29, "week": 149, "month": 399, "year": 999}
PLAN_HOURS = {"day": 24, "week": 168, "month": 720, "year": 8760}

# ═══════════════════════════════════════════════════════════
# ENCRYPTION
# ═══════════════════════════════════════════════════════════
try:
    _fernet = Fernet(ENCRYPTION_KEY.encode())
except Exception:
    _fernet = Fernet(Fernet.generate_key())
    print("⚠️ Bad encryption key, generated temporary one")

def encrypt_str(data: str) -> str:
    return _fernet.encrypt(data.encode()).decode()

def decrypt_str(token: str) -> Optional[str]:
    try:
        return _fernet.decrypt(token.encode()).decode()
    except Exception:
        return None

# ═══════════════════════════════════════════════════════════
# JSON FILE STORAGE (same pattern as reference)
# ═══════════════════════════════════════════════════════════
SETTINGS_FILE = Path("bot_settings.json")
PREMIUM_FILE  = Path("bot_premium.json")
USAGE_FILE    = Path("bot_usage.json")
ADMIN_FILE    = Path("bot_admin_cfg.json")
PROMO_FILE    = Path("bot_promos.json")
SESSIONS_FILE = Path("bot_sessions.json")
TRACK_FILE    = Path("bot_track_log.json")

def _load_json(path: Path) -> dict:
    if path.exists():
        try:
            with open(path, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def _save_json(path: Path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

# ─── User Settings ───
def get_user_cfg(uid: int) -> dict:
    data = _load_json(SETTINGS_FILE)
    default = {
        "channel": None, "topic": None,
        "replacements": {}, "deletions": [],
        "prefix": "", "suffix": "", "delay": 3,
        "thumbnail": "",          # file_id of custom thumbnail photo
        "watermark_text": "",     # text watermark for videos & PDFs
        "protect_content": False, # upload with forwarding restriction
        "video_watermark": False, # burn watermark into video (premium only)
    }
    stored = data.get(str(uid), {})
    default.update(stored)
    return default

def set_user_cfg(uid: int, cfg: dict):
    data = _load_json(SETTINGS_FILE)
    data[str(uid)] = cfg
    _save_json(SETTINGS_FILE, data)

# ─── Sessions (encrypted) ───
def save_session(uid: int, session_string: str):
    data = _load_json(SESSIONS_FILE)
    data[str(uid)] = encrypt_str(session_string)
    _save_json(SESSIONS_FILE, data)

def get_session(uid: int) -> Optional[str]:
    data = _load_json(SESSIONS_FILE)
    enc = data.get(str(uid))
    if enc:
        return decrypt_str(enc)
    return None

def delete_session(uid: int):
    data = _load_json(SESSIONS_FILE)
    data.pop(str(uid), None)
    _save_json(SESSIONS_FILE, data)

# ─── Premium ───
def _load_premium() -> dict:
    return _load_json(PREMIUM_FILE)

def is_premium(uid: int) -> bool:
    if uid == OWNER_ID:
        return True
    rec = _load_premium().get(str(uid))
    if not rec:
        return False
    return datetime.now(timezone.utc) < datetime.fromisoformat(rec["expiry"])

def get_premium_expiry(uid: int) -> Optional[str]:
    if uid == OWNER_ID:
        return "♾️ Lifetime (Owner)"
    rec = _load_premium().get(str(uid))
    if not rec:
        return None
    exp = datetime.fromisoformat(rec["expiry"])
    if datetime.now(timezone.utc) >= exp:
        return None
    return exp.strftime("%Y-%m-%d %H:%M UTC")

def grant_premium(uid: int, hours: int, label: str = ""):
    data = _load_premium()
    now = datetime.now(timezone.utc)
    base = now
    rec = data.get(str(uid))
    if rec:
        old_exp = datetime.fromisoformat(rec["expiry"])
        base = max(now, old_exp)
    new_exp = base + timedelta(hours=hours)
    data[str(uid)] = {"expiry": new_exp.isoformat(), "plan": label, "granted_at": now.isoformat()}
    _save_json(PREMIUM_FILE, data)
    return new_exp

def revoke_premium(uid: int):
    data = _load_premium()
    data.pop(str(uid), None)
    _save_json(PREMIUM_FILE, data)

# ─── Usage ───
def _today_str() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def get_daily_usage(uid: int) -> int:
    data = _load_json(USAGE_FILE)
    rec = data.get(str(uid), {})
    if rec.get("date") != _today_str():
        return 0
    return rec.get("count", 0)

def increment_usage(uid: int, amount: int = 1) -> int:
    data = _load_json(USAGE_FILE)
    today = _today_str()
    rec = data.get(str(uid), {})
    if rec.get("date") != today:
        rec = {"date": today, "count": 0}
    rec["count"] += amount
    data[str(uid)] = rec
    _save_json(USAGE_FILE, data)
    return rec["count"]

def check_limit(uid: int, needed: int = 1):
    if is_premium(uid):
        return True, 999999
    used = get_daily_usage(uid)
    remaining = max(0, FREE_DAILY_LIMIT - used)
    return remaining >= needed, remaining

# ─── Admin Config ───
def get_admin_cfg() -> dict:
    default = {
        "upi_id": "", "phone": "", "qr_file_id": "",
        "welcome_text": "", "welcome_image": "", "welcome_video": "",
        "razorpay_key": "", "razorpay_secret": "",
    }
    stored = _load_json(ADMIN_FILE)
    default.update(stored)
    return default

def update_admin_cfg(updates: dict):
    cfg = get_admin_cfg()
    cfg.update(updates)
    _save_json(ADMIN_FILE, cfg)

# ─── Promos ───
def create_promo(code, hours, label, max_uses=1):
    data = _load_json(PROMO_FILE)
    data[code.upper()] = {
        "duration_hours": hours, "plan_label": label,
        "max_uses": max_uses, "used_by": [],
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    _save_json(PROMO_FILE, data)

def redeem_promo(code: str, uid: int):
    data = _load_json(PROMO_FILE)
    rec = data.get(code.upper())
    if not rec:
        return False, "❌ Invalid promo code."
    if uid in rec.get("used_by", []):
        return False, "❌ Already used this code."
    if len(rec["used_by"]) >= rec.get("max_uses", 1):
        return False, "❌ Code expired / max uses reached."
    rec["used_by"].append(uid)
    _save_json(PROMO_FILE, data)
    exp = grant_premium(uid, rec["duration_hours"], rec["plan_label"])
    return True, f"🎉 Promo redeemed!\n\n✅ Plan: {rec['plan_label']}\n⏰ Until: {exp.strftime('%Y-%m-%d %H:%M UTC')}"

def delete_promo(code: str) -> bool:
    data = _load_json(PROMO_FILE)
    if code.upper() in data:
        del data[code.upper()]
        _save_json(PROMO_FILE, data)
        return True
    return False

# ─── Tracking ───
def track(user, action, **kwargs):
    entries = _load_json(TRACK_FILE) if TRACK_FILE.exists() else []
    if isinstance(entries, dict):
        entries = []
    entry = {
        "ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "user_id": user.id if user else None,
        "username": f"@{user.username}" if (user and user.username) else None,
        "action": action,
    }
    entry.update({k: v for k, v in kwargs.items() if v is not None})
    entries.append(entry)
    _save_json(TRACK_FILE, entries)

# ═══════════════════════════════════════════════════════════
# CAPTION RULES (same apply_rules pattern as reference)
# ═══════════════════════════════════════════════════════════
def apply_rules(text: Optional[str], cfg: dict) -> str:
    if not text:
        return ""
    text = str(text)
    for word in cfg.get("deletions", []):
        try:
            text = re.sub(re.escape(word), "", text, flags=re.IGNORECASE)
        except Exception:
            pass
    for old, new in cfg.get("replacements", {}).items():
        try:
            text = re.sub(re.escape(old), new, text, flags=re.IGNORECASE)
        except Exception:
            pass
    prefix = cfg.get("prefix", "")
    suffix = cfg.get("suffix", "")
    return prefix + text.strip() + suffix

# ═══════════════════════════════════════════════════════════
# LINK PARSING
# ═══════════════════════════════════════════════════════════
def parse_tme_link(text: str):
    m = re.search(r"https?://t\.me/(?:c/)?([^/\s]+)/(\d+)", text)
    if not m:
        return None
    chat_ref = m.group(1)
    msg_id = int(m.group(2))
    if chat_ref.isdigit():
        chat_ref = int(f"-100{chat_ref}")
    return chat_ref, msg_id

def extract_full_link(text: str) -> Optional[str]:
    m = re.search(r"(https?://t\.me/(?:c/)?[^/\s]+/\d+)", text)
    return m.group(1) if m else None

# ═══════════════════════════════════════════════════════════
# QR CODE
# ═══════════════════════════════════════════════════════════
def generate_payment_qr(plan_key: str, upi_id: str) -> Optional[bytes]:
    if not HAS_QRCODE or not upi_id:
        return None
    amount = PLAN_PRICES_INT.get(plan_key)
    if not amount:
        return None
    upi_url = f"upi://pay?pa={upi_id}&pn=SRCBot&am={amount}&cu=INR&tn=SRCBot-{plan_key}"
    try:
        qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=4)
        qr.add_data(upi_url)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        buf.seek(0)
        return buf.read()
    except Exception as e:
        log.error(f"QR generation error: {e}")
        return None

# ═══════════════════════════════════════════════════════════
# RUNTIME STATE
# ═══════════════════════════════════════════════════════════
inline_state:   dict[int, dict] = {}
pending_bulk:   dict[int, dict] = {}
cancel_flags:   dict[int, bool] = {}
active_tasks:   dict[int, asyncio.Task] = {}
user_clients:   dict[int, Client] = {}   # logged-in user pyrogram clients
login_clients:  dict[int, dict]  = {}    # temp login state

# ═══════════════════════════════════════════════════════════
# USER CLIENT MANAGEMENT
# ═══════════════════════════════════════════════════════════
async def get_user_client(uid: int) -> Optional[Client]:
    """Get or restore a user client from saved session."""
    if uid in user_clients:
        c = user_clients[uid]
        if c.is_connected:
            return c
    session_str = get_session(uid)
    if not session_str:
        return None
    try:
        c = Client(f"user_{uid}", api_id=API_ID, api_hash=API_HASH,
                   session_string=session_str, in_memory=True)
        await c.start()
        user_clients[uid] = c
        return c
    except AuthKeyUnregistered:
        delete_session(uid)
        return None
    except Exception as e:
        log.error(f"Restore session {uid}: {e}")
        return None

async def is_logged_in(uid: int) -> bool:
    c = await get_user_client(uid)
    return c is not None

# ═══════════════════════════════════════════════════════════
# SETTINGS DISPLAY (same pattern as reference)
# ═══════════════════════════════════════════════════════════
def format_settings_text(cfg: dict, uid: int) -> str:
    reps = cfg.get("replacements", {})
    dels = cfg.get("deletions", [])
    prefix = cfg.get("prefix", "")
    suffix = cfg.get("suffix", "")
    rep_lines = "\n".join(f"  • `{k}` → `{v or '(delete)'}`" for k, v in reps.items()) or "  None"
    del_lines = "\n".join(f"  • `{w}`" for w in dels) or "  None"
    logged = "✅ Yes" if get_session(uid) else "❌ No"

    thumb_status = "✅ Set" if cfg.get("thumbnail") else "❌ None"
    wm_status = f"`{cfg.get('watermark_text')}`" if cfg.get("watermark_text") else "❌ None"
    protect_status = "✅ ON" if cfg.get("protect_content") else "❌ OFF"
    vid_wm = "✅ ON" if cfg.get("video_watermark") else "❌ OFF"

    return (
        f"⚙️ **Your Settings**\n\n"
        f"🔐 Logged In: {logged}\n"
        f"📤 Destination: `{cfg.get('channel') or 'Not set'}`\n"
        f"📌 Topic: `{cfg.get('topic') or 'General'}`\n"
        f"⏱️ Delay: `{cfg.get('delay', 3)}s`\n"
        f"🔹 Prefix: `{prefix or 'None'}`\n"
        f"🔸 Suffix: `{suffix or 'None'}`\n\n"
        f"🖼 Thumbnail: {thumb_status}\n"
        f"💧 Watermark: {wm_status}\n"
        f"🎬 Video Watermark: {vid_wm} {'💎' if vid_wm == '✅ ON' else ''}\n"
        f"🔒 Protected Upload: {protect_status}\n\n"
        f"🔄 Replacements (max 2):\n{rep_lines}\n\n"
        f"🗑️ Deletions:\n{del_lines}"
    )

def build_settings_keyboard(cfg: dict) -> Optional[InlineKeyboardMarkup]:
    buttons = []
    for old in cfg.get("replacements", {}):
        buttons.append([InlineKeyboardButton(f"❌ replace: {old[:30]}", callback_data=f"delrep_{old[:40]}")])
    for word in cfg.get("deletions", []):
        buttons.append([InlineKeyboardButton(f"❌ delete: {word[:30]}", callback_data=f"deldelete_{word[:40]}")])
    if cfg.get("prefix"):
        buttons.append([InlineKeyboardButton("❌ clear prefix", callback_data="delprefix")])
    if cfg.get("suffix"):
        buttons.append([InlineKeyboardButton("❌ clear suffix", callback_data="delsuffix")])
    if cfg.get("thumbnail"):
        buttons.append([InlineKeyboardButton("❌ clear thumbnail", callback_data="delthumb")])
    if cfg.get("watermark_text"):
        buttons.append([InlineKeyboardButton(f"❌ watermark: {cfg['watermark_text'][:25]}", callback_data="delwatermark")])
    if cfg.get("protect_content"):
        buttons.append([InlineKeyboardButton("🔓 Turn OFF protected upload", callback_data="toggle_protect")])
    else:
        buttons.append([InlineKeyboardButton("🔒 Turn ON protected upload", callback_data="toggle_protect")])
    if cfg.get("video_watermark"):
        buttons.append([InlineKeyboardButton("🎬❌ Turn OFF video watermark", callback_data="toggle_vidwm")])
    buttons.append([InlineKeyboardButton("🔄 Refresh", callback_data="settings")])
    return InlineKeyboardMarkup(buttons) if buttons else None

# ═══════════════════════════════════════════════════════════
# SAFE DOWNLOAD DIRECTORY (Windows-safe filenames)
# ═══════════════════════════════════════════════════════════
DOWNLOAD_DIR = Path("downloads")
DOWNLOAD_DIR.mkdir(exist_ok=True)

import time

# ═══════════════════════════════════════════════════════════
# ANIMATED PROGRESS TRACKER
# ═══════════════════════════════════════════════════════════
class ProgressTracker:
    """Tracks download/upload progress with speed, ETA, animated bar."""

    CYCLE_FRAMES = ["🚲", "🏃", "🚗", "🚄", "✈️"]       # 1-5 MB/s
    ROCKET_FRAMES = ["🚀", "⚡", "💫", "🌟", "☄️"]       # 6+ MB/s

    def __init__(self, file_name: str, file_index: int, total_files: int):
        self.file_name = file_name
        self.file_index = file_index
        self.total_files = total_files
        self.current = 0
        self.total = 0
        self.speed = 0.0
        self.eta = 0.0
        self._last_bytes = 0
        self._last_time = time.time()
        self._frame = 0
        self._last_edit = 0.0       # throttle edits
        self.phase = "downloading"  # downloading / uploading

    def update(self, current: int, total: int):
        self.current = current
        self.total = total
        now = time.time()
        dt = now - self._last_time
        if dt >= 0.5:
            diff = current - self._last_bytes
            self.speed = diff / dt
            if self.speed > 0:
                self.eta = (total - current) / self.speed
            self._last_bytes = current
            self._last_time = now
            self._frame += 1

    # ── formatters ──
    def _fmt_size(self, b: float) -> str:
        for u in ("B", "KB", "MB", "GB"):
            if b < 1024:
                return f"{b:.1f} {u}"
            b /= 1024
        return f"{b:.1f} TB"

    def _fmt_speed(self) -> str:
        return f"{self._fmt_size(self.speed)}/s"

    def _fmt_eta(self) -> str:
        s = int(self.eta)
        if s < 60:
            return f"{s}s"
        if s < 3600:
            return f"{s // 60}m {s % 60}s"
        return f"{s // 3600}h {(s % 3600) // 60}m"

    def _pct(self) -> int:
        return int(self.current / self.total * 100) if self.total else 0

    def _bar(self, width: int = 10) -> str:
        filled = int(width * self._pct() / 100)
        return "█" * filled + "░" * (width - filled)

    def _speed_emoji(self) -> str:
        mb = self.speed / (1024 * 1024)
        if mb < 1:
            return "🐢"
        if mb <= 5:
            frames = self.CYCLE_FRAMES
        else:
            frames = self.ROCKET_FRAMES
        return frames[self._frame % len(frames)]

    def format_text(self, done: int, skipped: int, failed: int) -> str:
        emoji = self._speed_emoji()
        phase_map = {
            "downloading": ("⬇️", "Downloading"),
            "uploading": ("⬆️", "Uploading"),
            "watermarking": ("🎨", "Watermarking"),
        }
        phase_icon, phase_word = phase_map.get(self.phase, ("⬇️", "Processing"))

        return (
            f"📊 **Progress: {self.file_index}/{self.total_files}**\n"
            f"📄 File: `{self.file_name[:42]}…`\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"{phase_icon} {self._bar()} {self._pct()}%\n"
            f"{emoji} Speed: **{self._fmt_speed()}**\n"
            f"⏱️ ETA: `{self._fmt_eta()}`\n"
            f"📦 `{self._fmt_size(self.current)}` / `{self._fmt_size(self.total)}`\n"
            f"━━━━━━━━━━━━━━━━━━━━━\n"
            f"✅ Done: `{done}` | ⏭️ Skip: `{skipped}` | ❌ Fail: `{failed}`\n"
            f"🔄 {phase_word}…"
        )

    def should_edit(self) -> bool:
        """Throttle edits to max 1 per 2 seconds to avoid FloodWait."""
        now = time.time()
        if now - self._last_edit >= 2.0:
            self._last_edit = now
            return True
        return False

def safe_filename(name: str) -> str:
    """Remove illegal characters from filename for Windows."""
    if not name:
        return "file"
    # Replace characters illegal on Windows: \ / : * ? " < > |
    cleaned = re.sub(r'[\\/:*?"<>|]', '_', name)
    # Remove leading/trailing dots and spaces
    cleaned = cleaned.strip('. ')
    # Limit length
    if len(cleaned) > 150:
        ext = Path(cleaned).suffix
        cleaned = cleaned[:150 - len(ext)] + ext
    return cleaned or "file"

# ═══════════════════════════════════════════════════════════
# WATERMARK & THUMBNAIL PROCESSING
# ═══════════════════════════════════════════════════════════
THUMB_DIR = Path("thumbnails")
THUMB_DIR.mkdir(exist_ok=True)

async def save_thumbnail_from_msg(client: Client, uid: int, msg: Message) -> Optional[str]:
    """Download thumbnail from user's photo message and resize."""
    try:
        thumb_path = str(THUMB_DIR / f"thumb_{uid}.jpg")
        await client.download_media(msg, file_name=thumb_path)
        if HAS_PIL and os.path.exists(thumb_path):
            img = Image.open(thumb_path).convert("RGB")
            img.thumbnail((320, 320))
            img.save(thumb_path, "JPEG")
        log.info(f"Thumbnail saved for {uid}: {thumb_path}")
        return thumb_path
    except Exception as e:
        log.error(f"Thumbnail save error: {e}")
        return None

def get_thumb_path(uid: int) -> Optional[str]:
    p = str(THUMB_DIR / f"thumb_{uid}.jpg")
    return p if os.path.exists(p) else None

def add_video_watermark(input_path: str, watermark_text: str, output_path: str) -> bool:
    """Burn text watermark into video using ffmpeg."""
    if not HAS_FFMPEG or not watermark_text:
        return False
    try:
        escaped = watermark_text.replace("'", "'\\''").replace(":", "\\:")
        cmd = [
            "ffmpeg", "-y", "-i", input_path,
            "-vf", (
                f"drawtext=text='{escaped}'"
                f":fontsize=24:fontcolor=white@0.4"
                f":x=(w-text_w)/2:y=h-th-20"
                f":borderw=1:bordercolor=black@0.3"
            ),
            "-codec:a", "copy",
            "-preset", "ultrafast",
            output_path
        ]
        result = subprocess.run(cmd, capture_output=True, timeout=600)
        if result.returncode == 0 and os.path.exists(output_path):
            log.info(f"Video watermark applied: {output_path}")
            return True
        else:
            log.error(f"ffmpeg error: {result.stderr.decode()[-200:]}")
            return False
    except subprocess.TimeoutExpired:
        log.error("ffmpeg timeout (10 min)")
        return False
    except Exception as e:
        log.error(f"Video watermark error: {e}")
        return False

def add_pdf_watermark(input_path: str, watermark_text: str, output_path: str) -> bool:
    """Add text watermark to every page of a PDF."""
    if not HAS_PDF or not watermark_text:
        return False
    try:
        # Create watermark PDF
        wm_path = input_path + "_wm_overlay.pdf"
        reader = PdfReader(input_path)
        if len(reader.pages) == 0:
            return False
        page0 = reader.pages[0]
        pw = float(page0.mediabox.width)
        ph = float(page0.mediabox.height)

        c = rl_canvas.Canvas(wm_path, pagesize=(pw, ph))
        c.setFont("Helvetica", 36)
        c.setFillAlpha(0.15)
        c.saveState()
        c.translate(pw / 2, ph / 2)
        c.rotate(45)
        c.drawCentredString(0, 0, watermark_text)
        c.restoreState()
        c.save()

        wm_reader = PdfReader(wm_path)
        wm_page = wm_reader.pages[0]

        writer = PdfWriter()
        for page in reader.pages:
            page.merge_page(wm_page)
            writer.add_page(page)

        with open(output_path, "wb") as f:
            writer.write(f)

        os.remove(wm_path)
        log.info(f"PDF watermark applied: {output_path}")
        return True
    except Exception as e:
        log.error(f"PDF watermark error: {e}")
        return False

# ═══════════════════════════════════════════════════════════
# DOWNLOAD FROM PRIVATE CHANNEL + FORWARD TO DESTINATION
# ═══════════════════════════════════════════════════════════
async def download_and_forward(user_client: Client, bot: Client,
                                src_msg: Message, cfg: dict,
                                uid: int = 0,
                                tracker: ProgressTracker = None,
                                status_msg: Message = None,
                                done: int = 0, skipped: int = 0, failed: int = 0) -> bool:
    """
    1. Download media via USER CLIENT (has access to private/restricted channel)
    2. Apply caption rules (replace, delete, prefix, suffix)
    3. Re-upload via BOT to destination (or user_client as fallback)
    4. Show animated progress with speed/ETA during download AND upload
    """
    dest = cfg.get("channel")
    topic = cfg.get("topic")
    extra = {"reply_to_message_id": topic} if topic else {}

    original_text = src_msg.caption if src_msg.media else src_msg.text
    modified_text = apply_rules(original_text, cfg)
    if not modified_text:
        modified_text = None

    path = None
    extra_cleanup = []

    # ── Progress callback for download/upload ──
    async def _progress(current, total):
        if tracker:
            tracker.update(current, total)
            if status_msg and tracker.should_edit():
                try:
                    await status_msg.edit_text(
                        tracker.format_text(done, skipped, failed),
                        reply_markup=InlineKeyboardMarkup([
                            [InlineKeyboardButton("🛑 Cancel", callback_data="cancelb")]
                        ])
                    )
                except FloodWait as fw:
                    await asyncio.sleep(fw.value)
                except Exception:
                    pass

    try:
        # ── TEXT-ONLY MESSAGE (no media) ──
        if src_msg.text and not src_msg.media:
            send_text = modified_text or src_msg.text or ""
            try:
                await bot.send_message(dest, send_text, **extra)
            except (ChatAdminRequired, ChannelPrivate, PeerIdInvalid):
                await user_client.send_message(dest, send_text, **extra)
            return True

        # ── STICKER (no download needed) ──
        if src_msg.sticker:
            try:
                await bot.send_sticker(dest, src_msg.sticker.file_id, **extra)
            except Exception:
                path = await user_client.download_media(
                    src_msg, file_name=str(DOWNLOAD_DIR / "sticker.webp")
                )
                if path:
                    await user_client.send_sticker(dest, path, **extra)
            return True

        # ── MEDIA MESSAGE: Download via user_client, re-upload via bot ──

        # Build safe download path
        original_name = None
        if src_msg.document and src_msg.document.file_name:
            original_name = src_msg.document.file_name
        elif src_msg.video and src_msg.video.file_name:
            original_name = src_msg.video.file_name
        elif src_msg.audio and src_msg.audio.file_name:
            original_name = src_msg.audio.file_name

        if original_name:
            safe_name = safe_filename(original_name)
        else:
            if src_msg.photo:       safe_name = f"photo_{src_msg.id}.jpg"
            elif src_msg.video:     safe_name = f"video_{src_msg.id}.mp4"
            elif src_msg.audio:     safe_name = f"audio_{src_msg.id}.mp3"
            elif src_msg.voice:     safe_name = f"voice_{src_msg.id}.ogg"
            elif src_msg.video_note:safe_name = f"videonote_{src_msg.id}.mp4"
            elif src_msg.animation: safe_name = f"gif_{src_msg.id}.mp4"
            else:                   safe_name = f"file_{src_msg.id}"

        download_path = str(DOWNLOAD_DIR / safe_name)

        # STEP 1: Download via USER CLIENT with progress
        if tracker:
            tracker.file_name = original_name or safe_name
            tracker.phase = "downloading"
            tracker.current = 0
            tracker.total = 0
            tracker.speed = 0
            tracker._last_bytes = 0
            tracker._last_time = time.time()

        log.info(f"⬇️ Downloading: {safe_name}")
        path = await user_client.download_media(
            src_msg, file_name=download_path, progress=_progress
        )

        if not path or not os.path.exists(path):
            log.error(f"Download failed: {safe_name}")
            return False

        fsize = os.path.getsize(path)
        log.info(f"✅ Downloaded: {safe_name} ({fsize} bytes)")

        # Caption for re-upload
        cap = modified_text or src_msg.caption or None

        # ── STEP 2: APPLY WATERMARKS ──
        wm_text = cfg.get("watermark_text", "")
        upload_path = path          # may change if watermarked
        extra_cleanup = []          # extra files to delete

        # Video watermark (premium-only feature)
        is_video = bool(src_msg.video or src_msg.animation)
        if is_video and wm_text and cfg.get("video_watermark") and HAS_FFMPEG:
            if tracker:
                tracker.phase = "watermarking"
            wm_out = path + "_wm.mp4"
            ok_wm = add_video_watermark(path, wm_text, wm_out)
            if ok_wm:
                upload_path = wm_out
                extra_cleanup.append(wm_out)
                fsize = os.path.getsize(wm_out)
                log.info(f"🎨 Video watermark applied")

        # PDF watermark (any user with watermark_text)
        is_pdf = (original_name or "").lower().endswith(".pdf") if original_name else False
        if is_pdf and wm_text and HAS_PDF:
            if tracker:
                tracker.phase = "watermarking"
            wm_out = path + "_wm.pdf"
            ok_wm = add_pdf_watermark(path, wm_text, wm_out)
            if ok_wm:
                upload_path = wm_out
                extra_cleanup.append(wm_out)
                fsize = os.path.getsize(wm_out)
                log.info(f"🎨 PDF watermark applied")

        # ── STEP 3: Prepare thumbnail ──
        thumb = get_thumb_path(uid) if cfg.get("thumbnail") else None

        # ── STEP 4: Protected content flag ──
        protect = cfg.get("protect_content", False)

        # ── STEP 5: Re-upload via BOT to destination with progress ──
        if tracker:
            tracker.phase = "uploading"
            tracker.current = 0
            tracker.total = fsize
            tracker.speed = 0
            tracker._last_bytes = 0
            tracker._last_time = time.time()

        async def send_media(sender: Client):
            kw = dict(**extra)
            if protect:
                kw["protect_content"] = True

            if src_msg.photo:
                await sender.send_photo(dest, upload_path, caption=cap,
                    progress=_progress, **kw)
            elif src_msg.video:
                await sender.send_video(dest, upload_path, caption=cap,
                    thumb=thumb, progress=_progress, **kw)
            elif src_msg.document:
                await sender.send_document(dest, upload_path, caption=cap,
                    thumb=thumb, progress=_progress,
                    file_name=original_name or safe_name, **kw)
            elif src_msg.audio:
                await sender.send_audio(dest, upload_path, caption=cap,
                    thumb=thumb, progress=_progress, **kw)
            elif src_msg.voice:
                await sender.send_voice(dest, upload_path, caption=cap,
                    progress=_progress, **kw)
            elif src_msg.video_note:
                await sender.send_video_note(dest, upload_path,
                    thumb=thumb, progress=_progress, **kw)
            elif src_msg.animation:
                await sender.send_animation(dest, upload_path, caption=cap,
                    thumb=thumb, **kw)
            else:
                await sender.send_document(dest, upload_path, caption=cap,
                    thumb=thumb, progress=_progress, **kw)

        try:
            await send_media(bot)
        except (ChatAdminRequired, ChannelPrivate, PeerIdInvalid) as e:
            log.info(f"Bot can't send to {dest}, using user_client: {e}")
            await send_media(user_client)

        log.info(f"⬆️ Forwarded: {safe_name} → {dest}")
        return True

    except FloodWait as e:
        log.warning(f"FloodWait {e.value}s — waiting...")
        await asyncio.sleep(e.value)
        return await download_and_forward(
            user_client, bot, src_msg, cfg, uid, tracker, status_msg, done, skipped, failed
        )
    except Exception as e:
        log.error(f"download_and_forward error: {e}")
        return False
    finally:
        for f in [path] + extra_cleanup:
            if f and os.path.exists(f):
                try: os.remove(f)
                except Exception: pass

# ═══════════════════════════════════════════════════════════
# BULK COPY RUNNER
# ═══════════════════════════════════════════════════════════
async def run_bulk_copy(bot: Client, msg: Message, uid: int,
                        chat_id, start_id: int, quantity: int, cfg: dict):
    cancel_flags[uid] = False
    uc = await get_user_client(uid)
    if not uc:
        await msg.reply_text("❌ Session expired! Please login again.")
        return

    if not is_premium(uid):
        ok, remaining = check_limit(uid, 1)
        if not ok:
            await msg.reply_text("⛔ Daily free limit reached! Use 💎 Get Premium.")
            return
        if quantity > remaining:
            quantity = remaining

    status = await msg.reply_text(
        f"🚀 **Batch started!**\n\n"
        f"📌 From ID: `{start_id}`\n📦 Total: `{quantity}`\n"
        f"📤 Dest: `{cfg.get('channel')}`\n\n"
        f"⏳ Progress: 0 / {quantity}",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🛑 Cancel", callback_data="cancelb")]
        ])
    )

    done = skipped = failed = 0
    tracker = ProgressTracker("starting…", 0, quantity)
    try:
        for i in range(quantity):
            if cancel_flags.get(uid, False):
                await status.edit_text(
                    f"🛑 **Cancelled!**\n"
                    f"━━━━━━━━━━━━━━━━━━━━━\n"
                    f"✅ Copied: `{done}` | ⏭️ Skipped: `{skipped}` | ❌ Failed: `{failed}`\n"
                    f"📊 Stopped at `{i}/{quantity}`"
                )
                return

            mid = start_id + i
            try:
                src_msg = await uc.get_messages(chat_id, mid)
                if not src_msg or src_msg.empty:
                    skipped += 1
                else:
                    # Get file name for display
                    if src_msg.document and src_msg.document.file_name:
                        fname = src_msg.document.file_name
                    elif src_msg.video and src_msg.video.file_name:
                        fname = src_msg.video.file_name
                    elif src_msg.audio and src_msg.audio.file_name:
                        fname = src_msg.audio.file_name
                    elif src_msg.photo:
                        fname = f"photo_{mid}.jpg"
                    elif src_msg.text:
                        fname = f"text_{mid}"
                    else:
                        fname = f"media_{mid}"

                    # Update tracker for this file
                    tracker.file_name = fname
                    tracker.file_index = i + 1
                    tracker.current = 0
                    tracker.total = 0
                    tracker.speed = 0
                    tracker.eta = 0

                    ok = await download_and_forward(
                        uc, bot, src_msg, cfg, uid=uid,
                        tracker=tracker, status_msg=status,
                        done=done, skipped=skipped, failed=failed
                    )
                    if ok:
                        done += 1
                        if not is_premium(uid):
                            cnt = increment_usage(uid, 1)
                            if cnt >= FREE_DAILY_LIMIT:
                                await status.edit_text(
                                    f"⛔ **Daily limit reached!**\n\n"
                                    f"✅ `{done}` | ⏭️ `{skipped}` | ❌ `{failed}`"
                                )
                                return
                    else:
                        failed += 1

                # Show summary between files (for text msgs / skips)
                if not src_msg or src_msg.empty or (src_msg.text and not src_msg.media):
                    try:
                        overall_pct = int(((i + 1) / quantity) * 100)
                        bar_f = int(overall_pct / 10)
                        bar = "█" * bar_f + "░" * (10 - bar_f)
                        await status.edit_text(
                            f"📊 **Progress: {i+1}/{quantity}**\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"⬇️ {bar} {overall_pct}%\n"
                            f"━━━━━━━━━━━━━━━━━━━━━\n"
                            f"✅ Done: `{done}` | ⏭️ Skip: `{skipped}` | ❌ Fail: `{failed}`",
                            reply_markup=InlineKeyboardMarkup([
                                [InlineKeyboardButton("🛑 Cancel", callback_data="cancelb")]
                            ])
                        )
                    except Exception:
                        pass

                await asyncio.sleep(cfg.get("delay", BULK_DELAY))

            except FloodWait as e:
                await asyncio.sleep(e.value)
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.error(f"Bulk msg {mid}: {e}")
                failed += 1

    except asyncio.CancelledError:
        await status.edit_text(
            f"🛑 **Cancelled!**\n\n✅ `{done}` | ⏭️ `{skipped}` | ❌ `{failed}`"
        )
        return
    finally:
        cancel_flags.pop(uid, None)
        active_tasks.pop(uid, None)

    elapsed = time.time() - (tracker._last_time - tracker.eta if tracker.eta else time.time())
    track(msg.from_user, "bulk_done", copied=done, skipped=skipped, failed=failed, quantity=quantity)
    await status.edit_text(
        f"🎉 **Batch Complete!**\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 Total: `{quantity}` files\n"
        f"✅ Copied: `{done}`\n"
        f"⏭️ Skipped: `{skipped}`\n"
        f"❌ Failed: `{failed}`\n"
        f"━━━━━━━━━━━━━━━━━━━━━\n"
        f"📤 Dest: `{cfg.get('channel')}`\n"
        f"⬇️ ██████████ 100%  🎉"
    )

# ═══════════════════════════════════════════════════════════
# BOT CLIENT
# ═══════════════════════════════════════════════════════════
app = Client("src_bot", api_id=API_ID, api_hash=API_HASH, bot_token=BOT_TOKEN)

# ═══════════════════════════════════════════════════════════
# /start — Main Menu
# ═══════════════════════════════════════════════════════════
@app.on_message(filters.command("start") & filters.private)
async def cmd_start(client: Client, msg: Message):
    track(msg.from_user, "/start")
    uid = msg.from_user.id
    first_name = msg.from_user.first_name or "there"

    logged = bool(get_session(uid))
    if is_premium(uid):
        exp = get_premium_expiry(uid)
        status_line = f"💎 **Premium** | Expires: `{exp}`"
    else:
        used = get_daily_usage(uid)
        remaining = max(0, FREE_DAILY_LIMIT - used)
        status_line = f"🆓 **Free** | Used: `{used}/{FREE_DAILY_LIMIT}` | Left: `{remaining}`"

    login_line = "✅ Logged In" if logged else "❌ Not Logged In — tap Login first!"

    welcome = (
        f"Hey {first_name}! 👋\n\n"
        f"🔐 {login_line}\n"
        f"{status_line}\n\n"
        f"This bot downloads from **private/restricted** channels\n"
        f"and forwards to your destination.\n\n"
        f"📋 **Main Menu:**"
    )

    rows = []
    if not logged:
        rows.append([InlineKeyboardButton("🔐 LOGIN", callback_data="login")])
    else:
        rows.append([InlineKeyboardButton("🚪 Logout", callback_data="logout")])

    rows.extend([
        [InlineKeyboardButton("📤 Set Destination", callback_data="setchannel"),
         InlineKeyboardButton("📌 Set Topic", callback_data="settopic")],
        [InlineKeyboardButton("📱 My Settings", callback_data="settings"),
         InlineKeyboardButton("🗑 Clear Destination", callback_data="clearchannel")],
        [InlineKeyboardButton("🔄 Replace Word", callback_data="replace_ask"),
         InlineKeyboardButton("❌ Delete Word", callback_data="delete_ask")],
        [InlineKeyboardButton("🔹 Add Prefix", callback_data="prefix_ask"),
         InlineKeyboardButton("🔸 Add Suffix", callback_data="suffix_ask")],
        [InlineKeyboardButton("🖼 Set Thumbnail", callback_data="thumb_ask"),
         InlineKeyboardButton("💧 Set Watermark", callback_data="watermark_ask")],
        [InlineKeyboardButton("🔒 Protected Upload", callback_data="toggle_protect"),
         InlineKeyboardButton("🎬 Video Watermark 💎", callback_data="toggle_vidwm")],
        [InlineKeyboardButton("🧹 Clear All Rules", callback_data="clearrules"),
         InlineKeyboardButton("🛑 Cancel Batch", callback_data="cancelb")],
        [InlineKeyboardButton("⏱️ Set Delay", callback_data="setdelay_ask"),
         InlineKeyboardButton("💎 Get Premium", callback_data="getpremium")],
        [InlineKeyboardButton("🎟 Redeem Promo Code", callback_data="redeem_promo")],
    ])

    if uid == OWNER_ID:
        rows.append([InlineKeyboardButton("🛠 Admin Panel", callback_data="admin_panel")])

    acfg = get_admin_cfg()
    try:
        if acfg.get("welcome_video"):
            await msg.reply_video(acfg["welcome_video"], caption=welcome,
                                  reply_markup=InlineKeyboardMarkup(rows))
        elif acfg.get("welcome_image"):
            await msg.reply_photo(acfg["welcome_image"], caption=welcome,
                                  reply_markup=InlineKeyboardMarkup(rows))
        else:
            await msg.reply_text(welcome, reply_markup=InlineKeyboardMarkup(rows))
    except Exception:
        await msg.reply_text(welcome, reply_markup=InlineKeyboardMarkup(rows))

# ═══════════════════════════════════════════════════════════
# ADMIN PANEL
# ═══════════════════════════════════════════════════════════
async def send_admin_panel(source_msg):
    cfg = get_admin_cfg()
    upi_display = cfg.get('upi_id') or 'not set'
    text = (
        "🛠 **Admin Panel**\n\n"
        f"📱 UPI ID: `{upi_display}`\n"
        f"📞 Phone: `{cfg['phone'] or 'not set'}`\n"
        f"💳 Razorpay: `{'✅ set' if cfg['razorpay_key'] else '❌'}`\n"
        f"👋 Welcome: {'Text ✅' if cfg.get('welcome_text') else ''} "
        f"{'Image ✅' if cfg.get('welcome_image') else ''} "
        f"{'Video ✅' if cfg.get('welcome_video') else ''}\n\n"
        f"**Pricing:** Day {PREMIUM_PRICES['day']} | Week {PREMIUM_PRICES['week']} | "
        f"Month {PREMIUM_PRICES['month']} | Year {PREMIUM_PRICES['year']}"
    )
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("📱 Set UPI ID", callback_data="adm_set_upi"),
         InlineKeyboardButton("📞 Set Phone", callback_data="adm_set_phone")],
        [InlineKeyboardButton("💳 Set Razorpay", callback_data="adm_set_rzp")],
        [InlineKeyboardButton("✏️ Set Welcome Text", callback_data="adm_set_welcome_text"),
         InlineKeyboardButton("🖼 Set Welcome Image", callback_data="adm_set_welcome_image")],
        [InlineKeyboardButton("🎬 Set Welcome Video", callback_data="adm_set_welcome_video"),
         InlineKeyboardButton("🧹 Clear Welcome", callback_data="adm_clear_welcome")],
        [InlineKeyboardButton("🎟 Create Promo", callback_data="adm_create_promo"),
         InlineKeyboardButton("📋 List Promos", callback_data="adm_list_promos")],
        [InlineKeyboardButton("❌ Delete Promo", callback_data="adm_del_promo")],
        [InlineKeyboardButton("💎 Give Premium", callback_data="adm_give_premium"),
         InlineKeyboardButton("🚫 Revoke Premium", callback_data="adm_revoke_premium")],
        [InlineKeyboardButton("📋 List Premium", callback_data="adm_list_premium"),
         InlineKeyboardButton("📊 View Usage", callback_data="adm_view_usage")],
    ])
    await source_msg.reply_text(text, reply_markup=kb)

# ═══════════════════════════════════════════════════════════
# CALLBACK HANDLER (single handler, same pattern as reference)
# ═══════════════════════════════════════════════════════════
@app.on_callback_query()
async def handle_callback(client: Client, cb: CallbackQuery):
    data = cb.data
    uid  = cb.from_user.id

    # ─── Settings delete buttons (delrep_, deldelete_, delprefix, delsuffix) ───
    if data.startswith("delrep_"):
        old = data[7:]
        cfg = get_user_cfg(uid)
        reps = cfg.get("replacements", {})
        if old in reps:
            del reps[old]
            set_user_cfg(uid, cfg)
            await cb.answer(f"Deleted replacement: {old}")
        else:
            await cb.answer("Rule not found.")
        # Refresh settings
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    if data.startswith("deldelete_"):
        word = data[10:]
        cfg = get_user_cfg(uid)
        dels = cfg.get("deletions", [])
        if word in dels:
            dels.remove(word)
            set_user_cfg(uid, cfg)
            await cb.answer(f"Removed: {word}")
        else:
            await cb.answer("Word not found.")
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    if data == "delprefix":
        cfg = get_user_cfg(uid); cfg["prefix"] = ""; set_user_cfg(uid, cfg)
        await cb.answer("Prefix cleared.")
        text = format_settings_text(cfg, uid); mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    if data == "delsuffix":
        cfg = get_user_cfg(uid); cfg["suffix"] = ""; set_user_cfg(uid, cfg)
        await cb.answer("Suffix cleared.")
        text = format_settings_text(cfg, uid); mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    # ─── Login ───
    if data == "login":
        await cb.answer()
        await cb.message.reply_text(
            "🔐 **Login to Access Private Channels**\n\n"
            "Choose method:",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📱 Phone Number", callback_data="login_phone")],
                [InlineKeyboardButton("🐍 Pyrogram Session String", callback_data="login_session")],
            ])
        )
        return

    if data == "login_phone":
        await cb.answer()
        inline_state[uid] = {"action": "login_phone"}
        await cb.message.reply_text(
            "📱 **Phone Login**\n\n"
            "Send your phone number with country code:\n\n"
            "**Example:** `+919876543210`"
        )
        return

    if data == "login_session":
        await cb.answer()
        inline_state[uid] = {"action": "login_session"}
        await cb.message.reply_text(
            "🐍 **Session String Login**\n\n"
            "Send your Pyrogram session string.\n"
            "🔒 It will be encrypted and stored safely."
        )
        return

    if data == "logout":
        await cb.answer()
        if uid in user_clients:
            try: await user_clients[uid].stop()
            except: pass
            del user_clients[uid]
        delete_session(uid)
        await cb.message.reply_text("✅ **Logged out!** Session deleted.")
        return

    # ─── Set channel/topic/delay ───
    if data == "setchannel":
        await cb.answer()
        inline_state[uid] = {"action": "setchannel"}
        await cb.message.reply_text(
            "📤 **Set Destination**\n\n"
            "Send the channel/group:\n"
            "`@username` or `-100xxxxxxxxx`"
        )
        return

    if data == "settopic":
        await cb.answer()
        inline_state[uid] = {"action": "settopic"}
        await cb.message.reply_text(
            "📌 **Set Topic**\n\n"
            "Send the topic/thread ID number.\n"
            "(Send `0` for General)"
        )
        return

    if data == "setdelay_ask":
        await cb.answer()
        inline_state[uid] = {"action": "setdelay"}
        await cb.message.reply_text(
            "⏱️ **Set Delay**\n\n"
            "Send delay in seconds between uploads (1–60):"
        )
        return

    if data == "clearchannel":
        cfg = get_user_cfg(uid); cfg["channel"] = None; cfg["topic"] = None
        set_user_cfg(uid, cfg)
        await cb.message.reply_text("🗑️ Destination cleared.")
        await cb.answer("Cleared!")
        return

    if data == "settings":
        cfg = get_user_cfg(uid)
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        await client.send_message(cb.message.chat.id, text, reply_markup=mk)
        await cb.answer()
        return

    # ─── Caption rules ───
    if data == "replace_ask":
        await cb.answer()
        inline_state[uid] = {"action": "replace_old"}
        await cb.message.reply_text(
            "🔄 **Replace Word**\n\n"
            "Send me the word you want to **find/replace**.\n"
            "(Text only, no commands.)"
        )
        return

    if data == "delete_ask":
        await cb.answer()
        inline_state[uid] = {"action": "delete_word"}
        await cb.message.reply_text(
            "❌ **Delete Word**\n\n"
            "Send me the word to **delete from all captions**."
        )
        return

    if data == "prefix_ask":
        await cb.answer()
        inline_state[uid] = {"action": "set_prefix"}
        await cb.message.reply_text(
            "🔹 **Add Prefix**\n\n"
            "Send the text to add at the **beginning** of every caption.\n"
            "(Send a space to remove.)"
        )
        return

    if data == "suffix_ask":
        await cb.answer()
        inline_state[uid] = {"action": "set_suffix"}
        await cb.message.reply_text(
            "🔸 **Add Suffix**\n\n"
            "Send the text to add at the **end** of every caption.\n"
            "(Send a space to remove.)"
        )
        return

    if data == "clearrules":
        cfg = get_user_cfg(uid)
        cfg["replacements"] = {}; cfg["deletions"] = []; cfg["prefix"] = ""; cfg["suffix"] = ""
        set_user_cfg(uid, cfg)
        await cb.message.reply_text("🧹 All caption rules cleared.")
        await cb.answer("Cleared!")
        return

    # ─── Thumbnail ───
    if data == "thumb_ask":
        await cb.answer()
        inline_state[uid] = {"action": "set_thumbnail"}
        await cb.message.reply_text(
            "🖼 **Set Thumbnail**\n\n"
            "Send me a **photo** to use as thumbnail for all video/document uploads.\n\n"
            "• Will be resized to 320×320\n"
            "• Applied to videos, documents, audio"
        )
        return

    if data == "delthumb":
        cfg = get_user_cfg(uid)
        cfg["thumbnail"] = ""
        set_user_cfg(uid, cfg)
        # Delete file too
        tp = str(THUMB_DIR / f"thumb_{uid}.jpg")
        if os.path.exists(tp):
            try: os.remove(tp)
            except: pass
        await cb.answer("Thumbnail cleared!")
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    # ─── Watermark ───
    if data == "watermark_ask":
        await cb.answer()
        inline_state[uid] = {"action": "set_watermark"}
        await cb.message.reply_text(
            "💧 **Set Watermark Text**\n\n"
            "Send me the text to stamp on:\n"
            "• **PDFs** — diagonal text on every page\n"
            "• **Videos** — bottom text overlay (needs 🎬 Video Watermark ON)\n\n"
            "Example: `@MyChannel`\n\n"
            "Send a space to remove."
        )
        return

    if data == "delwatermark":
        cfg = get_user_cfg(uid)
        cfg["watermark_text"] = ""
        set_user_cfg(uid, cfg)
        await cb.answer("Watermark cleared!")
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    # ─── Protected Content Toggle ───
    if data == "toggle_protect":
        cfg = get_user_cfg(uid)
        cfg["protect_content"] = not cfg.get("protect_content", False)
        set_user_cfg(uid, cfg)
        state = "ON 🔒" if cfg["protect_content"] else "OFF 🔓"
        await cb.answer(f"Protected upload: {state}")
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    # ─── Video Watermark Toggle (Premium Only) ───
    if data == "toggle_vidwm":
        if not is_premium(uid):
            await cb.answer("💎 Video Watermark is a Premium feature!\nGet premium first.", show_alert=True)
            return
        if not HAS_FFMPEG:
            await cb.answer("⚠️ ffmpeg not installed on server. Video watermark unavailable.", show_alert=True)
            return
        cfg = get_user_cfg(uid)
        cfg["video_watermark"] = not cfg.get("video_watermark", False)
        set_user_cfg(uid, cfg)
        state = "ON 🎬" if cfg["video_watermark"] else "OFF"
        await cb.answer(f"Video watermark: {state}")
        text = format_settings_text(cfg, uid)
        mk = build_settings_keyboard(cfg)
        try: await cb.message.edit_text(text, reply_markup=mk)
        except: pass
        return

    # ─── Cancel ───
    if data == "cancelb":
        did = False
        if uid in active_tasks and not active_tasks[uid].done():
            cancel_flags[uid] = True
            active_tasks[uid].cancel()
            did = True
        if uid in pending_bulk:
            del pending_bulk[uid]
            did = True
        await cb.message.reply_text("🛑 Cancelled!" if did else "⚠️ No active batch.")
        await cb.answer()
        return

    # ─── Premium ───
    if data == "getpremium":
        await cb.answer()
        cfg = get_admin_cfg()
        upi = cfg.get("upi_id") or ""
        lines = [
            "💎 **Get Premium**\n",
            f"• ☀️ 1 Day  → {PREMIUM_PRICES['day']}",
            f"• 📅 1 Week → {PREMIUM_PRICES['week']}",
            f"• 🗓 1 Month → {PREMIUM_PRICES['month']}",
            f"• 🏆 1 Year  → {PREMIUM_PRICES['year']}\n",
        ]
        if upi: lines.append(f"📱 UPI: `{upi}`")
        if cfg["phone"]: lines.append(f"📞 Phone: `{cfg['phone']}`")
        lines.append("\n📲 Tap a plan below for **payment QR**.")
        lines.append("After payment, send screenshot to **@AKASHH955956**.")
        buttons = [
            [InlineKeyboardButton(f"☀️ QR – Day ({PREMIUM_PRICES['day']})", callback_data="payqr_day"),
             InlineKeyboardButton(f"📅 QR – Week ({PREMIUM_PRICES['week']})", callback_data="payqr_week")],
            [InlineKeyboardButton(f"🗓 QR – Month ({PREMIUM_PRICES['month']})", callback_data="payqr_month"),
             InlineKeyboardButton(f"🏆 QR – Year ({PREMIUM_PRICES['year']})", callback_data="payqr_year")],
            [InlineKeyboardButton("🎟 Redeem Promo Code", callback_data="redeem_promo")],
        ]
        await cb.message.reply_text("\n".join(lines), reply_markup=InlineKeyboardMarkup(buttons))
        return

    if data == "redeem_promo":
        await cb.answer()
        inline_state[uid] = {"action": "redeem_promo"}
        await cb.message.reply_text("🎟 **Redeem Promo Code**\n\nSend me your promo code:")
        return

    if data.startswith("payqr_"):
        await cb.answer("Generating QR…")
        plan_key = data[6:]
        labels = {"day": "1 Day", "week": "1 Week", "month": "1 Month", "year": "1 Year"}
        label = labels.get(plan_key, plan_key)
        price = PREMIUM_PRICES.get(plan_key, "")
        cfg = get_admin_cfg()
        upi = cfg.get("upi_id") or ""
        caption = (
            f"📲 **Payment QR — {label} ({price})**\n\n"
            f"💰 Amount: {price}\n"
            f"Scan with GPay/PhonePe/Paytm.\n"
        )
        if upi: caption += f"\n📱 UPI: `{upi}`"
        caption += "\n\n✅ After payment, send screenshot to **@AKASHH955956**."

        if upi and HAS_QRCODE:
            qr_bytes = generate_payment_qr(plan_key, upi)
            if qr_bytes:
                bio = io.BytesIO(qr_bytes); bio.name = f"qr_{plan_key}.png"
                await cb.message.reply_photo(bio, caption=caption)
                return
        await cb.message.reply_text(caption + "\n\n⚠️ QR not available. Contact admin.")
        return

    # ─── Admin Panel ───
    if data == "admin_panel":
        if uid != OWNER_ID:
            await cb.answer("❌ Unauthorized", show_alert=True); return
        await cb.answer()
        await send_admin_panel(cb.message)
        return

    if data.startswith("adm_"):
        if uid != OWNER_ID:
            await cb.answer("❌ Unauthorized", show_alert=True); return
        await cb.answer()
        action = data[4:]

        if action == "set_upi":
            inline_state[uid] = {"action": "adm_set_upi"}
            await cb.message.reply_text("Send the new **UPI ID**:")
        elif action == "set_phone":
            inline_state[uid] = {"action": "adm_set_phone"}
            await cb.message.reply_text("Send the **Phone number**:")
        elif action == "set_rzp":
            inline_state[uid] = {"action": "adm_set_rzp_key"}
            await cb.message.reply_text("Send the **Razorpay Key ID**:")
        elif action == "set_welcome_text":
            inline_state[uid] = {"action": "adm_set_welcome_text"}
            await cb.message.reply_text(
                "✏️ Send the new welcome text.\n\n"
                "Use `{name}` for user's name, `{status}` for plan status.\n"
                "Send `clear` to reset to default."
            )
        elif action == "set_welcome_image":
            inline_state[uid] = {"action": "adm_set_welcome_image"}
            await cb.message.reply_text("🖼 Send the photo. Send `clear` to remove.")
        elif action == "set_welcome_video":
            inline_state[uid] = {"action": "adm_set_welcome_video"}
            await cb.message.reply_text("🎬 Send the video. Send `clear` to remove.")
        elif action == "clear_welcome":
            update_admin_cfg({"welcome_text": "", "welcome_image": "", "welcome_video": ""})
            await cb.message.reply_text("🧹 Welcome cleared.")
        elif action == "create_promo":
            await cb.message.reply_text(
                "🎟 **Create Promo**\n\nChoose duration:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("☀️ 1 Day", callback_data="promo_dur_24_1Day")],
                    [InlineKeyboardButton("📅 1 Week", callback_data="promo_dur_168_1Week")],
                    [InlineKeyboardButton("🗓 1 Month", callback_data="promo_dur_720_1Month")],
                    [InlineKeyboardButton("🏆 1 Year", callback_data="promo_dur_8760_1Year")],
                ])
            )
        elif action == "list_promos":
            promos = _load_json(PROMO_FILE)
            if not promos:
                await cb.message.reply_text("No promos found.")
            else:
                lines = ["🎟 **Promo Codes:**\n"]
                for code, rec in promos.items():
                    lines.append(f"• `{code}` — {rec['plan_label']} | {len(rec.get('used_by',[]))}/{rec.get('max_uses',1)} used")
                await cb.message.reply_text("\n".join(lines))
        elif action == "del_promo":
            inline_state[uid] = {"action": "adm_del_promo"}
            await cb.message.reply_text("Send the promo code to **delete**:")
        elif action == "give_premium":
            inline_state[uid] = {"action": "adm_give_uid"}
            await cb.message.reply_text("💎 Send the **user ID**:")
        elif action == "revoke_premium":
            inline_state[uid] = {"action": "adm_revoke_uid"}
            await cb.message.reply_text("Send the **user ID** to revoke:")
        elif action == "list_premium":
            pdata = _load_premium()
            if not pdata:
                await cb.message.reply_text("No premium users.")
            else:
                lines = ["💎 **Premium Users:**\n"]
                now = datetime.now(timezone.utc)
                for suid, rec in pdata.items():
                    exp = datetime.fromisoformat(rec["expiry"])
                    st = "✅" if exp > now else "❌"
                    lines.append(f"• `{suid}` — {rec.get('plan','?')} {st} until `{exp.strftime('%Y-%m-%d')}`")
                await cb.message.reply_text("\n".join(lines))
        elif action == "view_usage":
            udata = _load_json(USAGE_FILE)
            today = _today_str()
            lines = [f"📊 **Usage ({today}):**\n"]
            for s, rec in udata.items():
                if rec.get("date") == today:
                    lines.append(f"• `{s}` — {rec['count']} copies")
            if len(lines) == 1: lines.append("No usage today.")
            await cb.message.reply_text("\n".join(lines))
        return

    if data.startswith("promo_dur_"):
        if uid != OWNER_ID: await cb.answer("❌", show_alert=True); return
        await cb.answer()
        parts = data[10:].split("_", 1)
        hours = int(parts[0])
        label = parts[1] if len(parts) > 1 else f"{hours}h"
        inline_state[uid] = {"action": "adm_promo_uses", "hours": hours, "label": label}
        await cb.message.reply_text(f"Plan: **{label}**\n\nHow many uses? (1-100)")
        return

    if data.startswith("grant_plan_"):
        if uid != OWNER_ID: await cb.answer("❌", show_alert=True); return
        await cb.answer()
        rest = data[11:]; parts = rest.split("_", 2)
        hours = int(parts[0]); target = int(parts[1])
        label = parts[2] if len(parts) > 2 else f"{hours}h"
        exp = grant_premium(target, hours, label)
        await cb.message.reply_text(
            f"✅ Premium granted!\n👤 `{target}`\n📋 {label}\n⏰ Until: `{exp.strftime('%Y-%m-%d %H:%M UTC')}`"
        )
        try:
            await client.send_message(target, f"🎉 You got **{label}** Premium!\n⏰ Until: `{exp.strftime('%Y-%m-%d %H:%M UTC')}`")
        except: pass
        return

    await cb.answer()

# ═══════════════════════════════════════════════════════════
# MESSAGE HANDLER (single handler, same pattern as reference)
# ═══════════════════════════════════════════════════════════
@app.on_message(filters.private & ~filters.command(["start", "cancel"]))
async def handle_message(client: Client, msg: Message):
    uid  = msg.from_user.id
    text = msg.text or msg.caption or ""

    # ─── Handle inline_state input ───
    if uid in inline_state:
        state  = inline_state[uid]
        action = state["action"]
        # Skip commands but NOT photos/media
        if text.startswith("/") and not msg.photo and not msg.video:
            inline_state.pop(uid, None)
            return
        cfg = get_user_cfg(uid)

        # ── Login flows ──
        if action == "login_phone":
            phone = text.strip()
            status_msg = await msg.reply_text("⏳ Sending OTP…")
            try:
                c = Client(f"user_{uid}", api_id=API_ID, api_hash=API_HASH, in_memory=True)
                await c.connect()
                sent = await c.send_code(phone)
                login_clients[uid] = {"client": c, "phone": phone, "hash": sent.phone_code_hash}
                inline_state[uid] = {"action": "login_code"}
                await status_msg.edit_text("📲 **OTP Sent!**\n\nEnter the code you received:")
            except FloodWait as e:
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"⚠️ Please wait {e.value} seconds and try again.")
            except Exception as e:
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"❌ Error: `{e}`")
            return

        if action == "login_code":
            status_msg = await msg.reply_text("⏳ Verifying…")
            try:
                await msg.delete()
            except: pass
            lc = login_clients.get(uid)
            if not lc:
                inline_state.pop(uid, None)
                await status_msg.edit_text("❌ No login in progress. Try again.")
                return
            try:
                await lc["client"].sign_in(lc["phone"], lc["hash"], text.strip())
                ss = await lc["client"].export_session_string()
                save_session(uid, ss)
                user_clients[uid] = lc["client"]
                login_clients.pop(uid, None)
                inline_state.pop(uid, None)
                await status_msg.edit_text("✅ **Login Successful!**\n\n🔐 Session encrypted & saved.\n\nNow set your destination with 📤 Set Destination from /start menu.")
            except SessionPasswordNeeded:
                inline_state[uid] = {"action": "login_2fa"}
                await status_msg.edit_text("🔐 **2FA Password Required**\n\nEnter your two-factor authentication password:")
            except PhoneCodeInvalid:
                await status_msg.edit_text("❌ Invalid code. Try again:")
            except PhoneCodeExpired:
                inline_state.pop(uid, None)
                login_clients.pop(uid, None)
                await status_msg.edit_text("❌ Code expired. Start login again.")
            except Exception as e:
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"❌ Error: `{e}`")
            return

        if action == "login_2fa":
            status_msg = await msg.reply_text("⏳ Verifying password…")
            try: await msg.delete()
            except: pass
            lc = login_clients.get(uid)
            if not lc:
                inline_state.pop(uid, None)
                await status_msg.edit_text("❌ No login in progress.")
                return
            try:
                await lc["client"].check_password(text.strip())
                ss = await lc["client"].export_session_string()
                save_session(uid, ss)
                user_clients[uid] = lc["client"]
                login_clients.pop(uid, None)
                inline_state.pop(uid, None)
                await status_msg.edit_text("✅ **Login Successful!** Session saved.")
            except Exception as e:
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"❌ Wrong password: `{e}`")
            return

        if action == "login_session":
            status_msg = await msg.reply_text("⏳ Verifying session…")
            try: await msg.delete()
            except: pass
            try:
                c = Client(f"user_{uid}", api_id=API_ID, api_hash=API_HASH,
                           session_string=text.strip(), in_memory=True)
                await c.start()
                me = await c.get_me()
                save_session(uid, text.strip())
                user_clients[uid] = c
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"✅ **Logged in as {me.first_name}!**\nSession saved.")
            except Exception as e:
                inline_state.pop(uid, None)
                await status_msg.edit_text(f"❌ Invalid session: `{e}`")
            return

        # ── Settings inputs ──
        if action == "setchannel":
            cfg["channel"] = text.strip()
            set_user_cfg(uid, cfg)
            del inline_state[uid]
            await msg.reply_text(f"✅ Destination set: `{cfg['channel']}`")
            return

        if action == "settopic":
            try:
                tid = int(text.strip())
                cfg["topic"] = tid if tid != 0 else None
            except: cfg["topic"] = None
            set_user_cfg(uid, cfg)
            del inline_state[uid]
            await msg.reply_text(f"✅ Topic set: `{cfg['topic'] or 'General'}`")
            return

        if action == "setdelay":
            try:
                d = max(1, min(60, int(text.strip())))
                cfg["delay"] = d
                set_user_cfg(uid, cfg)
                del inline_state[uid]
                await msg.reply_text(f"✅ Delay set: `{d}s`")
            except:
                await msg.reply_text("⚠️ Send a number 1-60.")
            return

        # ── Caption rule inputs ──
        if action == "replace_old":
            inline_state[uid] = {"action": "replace_new", "old": text.strip()}
            await msg.reply_text(
                f"✅ Find: `{text.strip()}`\n\n"
                "Now send the **replacement word**.\n"
                "(Send a space to just delete it.)"
            )
            return

        if action == "replace_new":
            old = state.get("old", "")
            new = text.strip()
            reps = cfg.get("replacements", {})
            if len(reps) >= 2 and old not in reps:
                del inline_state[uid]
                await msg.reply_text("⚠️ Max 2 replacements. Remove one first from ⚙️ Settings.")
                return
            reps[old] = new
            set_user_cfg(uid, cfg)
            del inline_state[uid]
            act = "deleted" if new == "" else f"→ `{new}`"
            await msg.reply_text(f"✅ Rule: `{old}` {act}")
            return

        if action == "delete_word":
            word = text.strip()
            if word not in cfg.get("deletions", []):
                cfg.setdefault("deletions", []).append(word)
                set_user_cfg(uid, cfg)
            del inline_state[uid]
            await msg.reply_text(f"✅ `{word}` will be deleted from captions.")
            return

        if action == "set_prefix":
            p = text if text.strip() != "" else ""
            if text == " ": p = ""
            cfg["prefix"] = p
            set_user_cfg(uid, cfg)
            del inline_state[uid]
            await msg.reply_text(f"✅ Prefix: `{p or '(removed)'}`")
            return

        if action == "set_suffix":
            s = text if text.strip() != "" else ""
            if text == " ": s = ""
            cfg["suffix"] = s
            set_user_cfg(uid, cfg)
            del inline_state[uid]
            await msg.reply_text(f"✅ Suffix: `{s or '(removed)'}`")
            return

        # ── Thumbnail ──
        if action == "set_thumbnail":
            if msg.photo:
                file_id = msg.photo.file_id
                cfg["thumbnail"] = file_id
                set_user_cfg(uid, cfg)
                await save_thumbnail_from_msg(client, uid, msg)
                del inline_state[uid]
                await msg.reply_text("✅ **Thumbnail saved!**\n\nWill be used for videos, documents & audio.")
            else:
                await msg.reply_text("⚠️ Please send a **photo** (as image, not as file).")
            return

        # ── Watermark text ──
        if action == "set_watermark":
            wm = text.strip()
            if wm == "" or wm == " ":
                cfg["watermark_text"] = ""
                set_user_cfg(uid, cfg)
                del inline_state[uid]
                await msg.reply_text("✅ Watermark removed.")
            else:
                cfg["watermark_text"] = wm
                set_user_cfg(uid, cfg)
                del inline_state[uid]
                await msg.reply_text(
                    f"✅ **Watermark set:** `{wm}`\n\n"
                    f"📄 PDFs — diagonal stamp on every page\n"
                    f"🎬 Videos — bottom overlay (needs 🎬 Video Watermark ON)"
                )
            return

        if action == "redeem_promo":
            del inline_state[uid]
            ok, reply = redeem_promo(text.strip(), uid)
            await msg.reply_text(reply)
            return

        # ── Admin inputs ──
        if action == "adm_set_upi":
            update_admin_cfg({"upi_id": text.strip()})
            del inline_state[uid]
            await msg.reply_text(f"✅ UPI set: `{text.strip()}`")
            return

        if action == "adm_set_phone":
            update_admin_cfg({"phone": text.strip()})
            del inline_state[uid]
            await msg.reply_text(f"✅ Phone set: `{text.strip()}`")
            return

        if action == "adm_set_rzp_key":
            update_admin_cfg({"razorpay_key": text.strip()})
            inline_state[uid] = {"action": "adm_set_rzp_secret"}
            await msg.reply_text("✅ Key saved. Now send the **Razorpay Secret**:")
            return

        if action == "adm_set_rzp_secret":
            update_admin_cfg({"razorpay_secret": text.strip()})
            del inline_state[uid]
            await msg.reply_text("✅ Razorpay credentials saved!")
            return

        if action == "adm_set_welcome_text":
            if text.strip().lower() == "clear":
                update_admin_cfg({"welcome_text": ""})
                del inline_state[uid]
                await msg.reply_text("🧹 Welcome text cleared.")
            else:
                update_admin_cfg({"welcome_text": text})
                del inline_state[uid]
                await msg.reply_text("✅ Welcome text saved!")
            return

        if action == "adm_set_welcome_image":
            if msg.text and msg.text.strip().lower() == "clear":
                update_admin_cfg({"welcome_image": ""})
                del inline_state[uid]
                await msg.reply_text("🧹 Welcome image cleared.")
            elif msg.photo:
                update_admin_cfg({"welcome_image": msg.photo.file_id})
                del inline_state[uid]
                await msg.reply_text("✅ Welcome image saved!")
            else:
                await msg.reply_text("⚠️ Send a photo or `clear`.")
            return

        if action == "adm_set_welcome_video":
            if msg.text and msg.text.strip().lower() == "clear":
                update_admin_cfg({"welcome_video": ""})
                del inline_state[uid]
                await msg.reply_text("🧹 Welcome video cleared.")
            elif msg.video:
                update_admin_cfg({"welcome_video": msg.video.file_id})
                del inline_state[uid]
                await msg.reply_text("✅ Welcome video saved!")
            else:
                await msg.reply_text("⚠️ Send a video or `clear`.")
            return

        if action == "adm_promo_uses":
            if not text.strip().isdigit():
                await msg.reply_text("⚠️ Send a number 1-100.")
                return
            max_uses = max(1, min(100, int(text.strip())))
            hours = state.get("hours", 24); label = state.get("label", "Custom")
            code = "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))
            create_promo(code, hours, label, max_uses)
            del inline_state[uid]
            await msg.reply_text(f"🎟 **Promo Created!**\n\nCode: `{code}`\nPlan: {label}\nUses: {max_uses}")
            return

        if action == "adm_del_promo":
            del inline_state[uid]
            await msg.reply_text("🗑️ Deleted!" if delete_promo(text.strip()) else "⚠️ Not found.")
            return

        if action == "adm_give_uid":
            if not text.strip().lstrip("-").isdigit():
                await msg.reply_text("⚠️ Invalid ID.")
                return
            target = int(text.strip())
            del inline_state[uid]
            await msg.reply_text(
                f"👤 User: `{target}`\n\nChoose plan:",
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("☀️ 1 Day", callback_data=f"grant_plan_24_{target}_1Day"),
                     InlineKeyboardButton("📅 1 Week", callback_data=f"grant_plan_168_{target}_1Week")],
                    [InlineKeyboardButton("🗓 1 Month", callback_data=f"grant_plan_720_{target}_1Month"),
                     InlineKeyboardButton("🏆 1 Year", callback_data=f"grant_plan_8760_{target}_1Year")],
                ])
            )
            return

        if action == "adm_revoke_uid":
            if not text.strip().lstrip("-").isdigit():
                await msg.reply_text("⚠️ Invalid ID.")
                return
            revoke_premium(int(text.strip()))
            del inline_state[uid]
            await msg.reply_text(f"🚫 Premium revoked for `{text.strip()}`.")
            return

        # Unknown state
        inline_state.pop(uid, None)
        return

    # ─── Pending bulk quantity ───
    if uid in pending_bulk:
        pending = pending_bulk.pop(uid)
        if not text.strip().isdigit() or int(text.strip()) < 1:
            await msg.reply_text("⚠️ Send a valid number. Send the link again to retry.")
            return
        quantity = int(text.strip())
        if quantity > 10_000_000:
            await msg.reply_text("⚠️ Max 10,000,000.")
            return

        cfg = get_user_cfg(uid)
        dest = cfg.get("channel") or msg.chat.id
        topic = cfg.get("topic") if cfg.get("channel") else None
        bulk_cfg = cfg.copy()
        bulk_cfg["channel"] = dest
        bulk_cfg["topic"] = topic

        if uid in active_tasks and not active_tasks[uid].done():
            active_tasks[uid].cancel()

        task = asyncio.create_task(
            run_bulk_copy(client, msg, uid, pending["chat_id"],
                          pending["start_msg_id"], quantity, bulk_cfg)
        )
        active_tasks[uid] = task
        return

    # ─── Link detection → start batch ───
    parsed = parse_tme_link(text)
    if parsed:
        if not get_session(uid):
            await msg.reply_text("❌ You need to **login** first!\n\nPress /start → 🔐 LOGIN")
            return

        chat_ref, msg_id = parsed
        cfg = get_user_cfg(uid)
        dest = cfg.get("channel")
        if not dest:
            await msg.reply_text("❌ No destination set!\n\nPress /start → 📤 Set Destination")
            return

        pending_bulk[uid] = {"chat_id": chat_ref, "start_msg_id": msg_id}
        track(msg.from_user, "link_detected", source=str(chat_ref), msg_id=msg_id)
        await msg.reply_text(
            f"🔗 **Link detected!**\n\n"
            f"📌 Start ID: `{msg_id}`\n"
            f"📤 Dest: `{dest}`\n\n"
            f"**How many messages to copy?**\n"
            f"_(Send a number, max 10,000,000)_\n\n"
            f"Send /start to cancel."
        )
        return

# ═══════════════════════════════════════════════════════════
# /cancel COMMAND
# ═══════════════════════════════════════════════════════════
@app.on_message(filters.command("cancel") & filters.private)
async def cmd_cancel(_, msg: Message):
    uid = msg.from_user.id
    did = False
    if uid in active_tasks and not active_tasks[uid].done():
        cancel_flags[uid] = True
        active_tasks[uid].cancel()
        did = True
    if uid in pending_bulk:
        del pending_bulk[uid]
        did = True
    if uid in inline_state:
        del inline_state[uid]
        did = True
    await msg.reply_text("🛑 Cancelled!" if did else "⚠️ Nothing to cancel.")

# ═══════════════════════════════════════════════════════════
# STARTUP — exact same pattern as the reference bot: app.run()
# ═══════════════════════════════════════════════════════════
if __name__ == "__main__":
    print("🤖 Save Restricted Content Bot starting…")
    print(f"👤 Owner: {OWNER_ID}")
    print(f"💾 DB Group: {DATABASE_CHAT_ID}")
    print("📌 Press Ctrl+C to stop.\n")
    app.run()
