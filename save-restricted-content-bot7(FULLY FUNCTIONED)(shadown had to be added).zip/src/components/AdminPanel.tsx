import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Settings, Users, CreditCard, MessageSquare, Image,
  Ban, Gift, IndianRupee, Timer, Shield, BarChart3,
  ChevronRight, Bell, Database, Activity
} from 'lucide-react';

const adminFeatures = [
  {
    title: 'User Management',
    icon: Users,
    color: 'from-blue-500 to-cyan-500',
    items: [
      { label: 'View all users', desc: 'List all registered users with status' },
      { label: 'Give Premium', desc: 'Activate premium for any user' },
      { label: 'Ban User', desc: 'Block users from using the bot' },
      { label: 'User Activity', desc: 'Track downloads, forwards per user' },
    ],
  },
  {
    title: 'Payment Settings',
    icon: CreditCard,
    color: 'from-green-500 to-emerald-500',
    items: [
      { label: 'Set UPI ID', desc: 'Configure payment UPI address' },
      { label: 'Set Razorpay', desc: 'Integrate Razorpay payment gateway' },
      { label: 'Plan Pricing', desc: 'Adjust day/week/month prices in ₹' },
      { label: 'Promo Codes', desc: 'Create & manage promotional codes' },
    ],
  },
  {
    title: 'Welcome Config',
    icon: MessageSquare,
    color: 'from-purple-500 to-pink-500',
    items: [
      { label: 'Welcome Message', desc: 'Customize the /start greeting' },
      { label: 'Welcome Image', desc: 'Set a welcome banner image' },
      { label: 'Welcome Video', desc: 'Set a welcome introduction video' },
      { label: 'Help Text', desc: 'Customize the /help response' },
    ],
  },
  {
    title: 'Bot Controls',
    icon: Settings,
    color: 'from-orange-500 to-red-500',
    items: [
      { label: 'Upload Delay', desc: 'Set global delay between uploads' },
      { label: 'Flood Protection', desc: 'Configure anti-flood settings' },
      { label: 'Clone Bot Token', desc: 'Manage bot tokens for uploads' },
      { label: 'Broadcast', desc: 'Send announcements to all users' },
    ],
  },
];

const statsData = [
  { label: 'Total Users', value: '1,247', icon: Users, color: 'text-blue-400' },
  { label: 'Premium Users', value: '342', icon: Shield, color: 'text-purple-400' },
  { label: 'Downloads Today', value: '8,591', icon: BarChart3, color: 'text-green-400' },
  { label: 'Active Sessions', value: '89', icon: Activity, color: 'text-orange-400' },
];

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState(0);

  return (
    <section id="admin" className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-danger/30 to-transparent" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-danger/10 border border-danger/20 rounded-full mb-4">
            <Shield className="w-4 h-4 text-danger" />
            <span className="text-sm font-medium text-danger">Admin Only</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Admin Panel</span>
          </h2>
          <p className="text-text-dim max-w-xl mx-auto text-lg">
            Full control over your bot — manage users, payments, and settings via inline buttons
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Sidebar - Admin Dashboard Preview */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-4"
          >
            {/* Stats */}
            <div className="bg-card border border-border rounded-2xl p-6 mb-6">
              <h3 className="text-sm font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
                <BarChart3 className="w-4 h-4" />
                Dashboard Stats
              </h3>
              <div className="space-y-4">
                {statsData.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <div key={stat.label} className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Icon className={`w-5 h-5 ${stat.color}`} />
                        <span className="text-sm text-text-dim">{stat.label}</span>
                      </div>
                      <span className="text-lg font-bold text-white">{stat.value}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick actions */}
            <div className="bg-card border border-border rounded-2xl p-6">
              <h3 className="text-sm font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
                <Bell className="w-4 h-4" />
                Quick Actions
              </h3>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { icon: Gift, label: 'Promo', color: 'bg-purple-500/20 text-purple-400' },
                  { icon: Ban, label: 'Ban User', color: 'bg-red-500/20 text-red-400' },
                  { icon: IndianRupee, label: 'Revenue', color: 'bg-green-500/20 text-green-400' },
                  { icon: Database, label: 'Logs', color: 'bg-blue-500/20 text-blue-400' },
                  { icon: Timer, label: 'Delay', color: 'bg-orange-500/20 text-orange-400' },
                  { icon: Image, label: 'Welcome', color: 'bg-pink-500/20 text-pink-400' },
                ].map((action) => {
                  const Icon = action.icon;
                  return (
                    <motion.button
                      key={action.label}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className={`flex flex-col items-center gap-2 p-3 rounded-xl ${action.color} transition-all`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-xs font-semibold">{action.label}</span>
                    </motion.button>
                  );
                })}
              </div>
            </div>
          </motion.div>

          {/* Main panel */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-8"
          >
            {/* Tabs */}
            <div className="flex flex-wrap gap-2 mb-6">
              {adminFeatures.map((feat, i) => {
                const Icon = feat.icon;
                return (
                  <motion.button
                    key={feat.title}
                    onClick={() => setActiveTab(i)}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                      activeTab === i
                        ? 'bg-gradient-to-r ' + feat.color + ' text-white shadow-lg'
                        : 'bg-card border border-border text-text-dim hover:text-white'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {feat.title}
                  </motion.button>
                );
              })}
            </div>

            {/* Tab content */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="bg-card border border-border rounded-2xl overflow-hidden"
              >
                {/* Tab header */}
                <div className={`bg-gradient-to-r ${adminFeatures[activeTab].color} p-6`}>
                  <div className="flex items-center gap-3">
                    {(() => {
                      const Icon = adminFeatures[activeTab].icon;
                      return <Icon className="w-8 h-8 text-white" />;
                    })()}
                    <div>
                      <h3 className="text-xl font-bold text-white">
                        {adminFeatures[activeTab].title}
                      </h3>
                      <p className="text-white/70 text-sm">
                        Manage via inline keyboard buttons in bot
                      </p>
                    </div>
                  </div>
                </div>

                {/* Items */}
                <div className="p-4 space-y-2">
                  {adminFeatures[activeTab].items.map((item, idx) => (
                    <motion.div
                      key={item.label}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.1 }}
                      className="flex items-center justify-between p-4 bg-darker/50 hover:bg-card-hover border border-border/50 rounded-xl transition-all group cursor-pointer"
                    >
                      <div>
                        <h4 className="text-sm font-semibold text-white">{item.label}</h4>
                        <p className="text-xs text-text-dim mt-0.5">{item.desc}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-text-dim group-hover:text-white transition-colors" />
                    </motion.div>
                  ))}
                </div>

                {/* Inline button preview */}
                <div className="px-4 pb-6">
                  <p className="text-xs text-text-dim mb-3 text-center">
                    Bot Inline Keyboard Preview
                  </p>
                  <div className="bg-telegram/10 border border-telegram/20 rounded-xl p-4">
                    <div className="grid grid-cols-2 gap-2">
                      {adminFeatures[activeTab].items.map((item) => (
                        <motion.div
                          key={item.label}
                          whileHover={{ scale: 1.02 }}
                          className="bg-telegram/20 hover:bg-telegram/30 border border-telegram/30 rounded-lg px-3 py-2 text-center text-xs font-semibold text-telegram cursor-pointer transition-all"
                        >
                          {item.label}
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
