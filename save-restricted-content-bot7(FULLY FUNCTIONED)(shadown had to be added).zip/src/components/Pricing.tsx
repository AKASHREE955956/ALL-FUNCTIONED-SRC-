import { useState } from 'react';
import { motion } from 'framer-motion';
import { QRCodeSVG } from 'qrcode.react';
import { Crown, Zap, Star, Check, Sparkles, IndianRupee } from 'lucide-react';

const plans = [
  {
    name: 'Daily',
    price: 29,
    duration: '1 Day',
    icon: Zap,
    color: 'from-blue-500 to-cyan-500',
    borderColor: 'border-blue-500/30',
    popular: false,
    features: [
      'Single & batch download',
      'Caption modification',
      'Progress tracking',
      'Basic support',
    ],
  },
  {
    name: 'Weekly',
    price: 149,
    duration: '7 Days',
    icon: Star,
    color: 'from-purple-500 to-pink-500',
    borderColor: 'border-purple-500/30',
    popular: true,
    features: [
      'Everything in Daily',
      'Clone bot support',
      'Priority queue',
      'Custom delay settings',
      'Premium support',
    ],
  },
  {
    name: 'Monthly',
    price: 399,
    duration: '30 Days',
    icon: Crown,
    color: 'from-amber-500 to-orange-500',
    borderColor: 'border-amber-500/30',
    popular: false,
    features: [
      'Everything in Weekly',
      'Unlimited batch size',
      'Fastest processing',
      'Admin-level delay control',
      'Lifetime updates',
      'VIP support 24/7',
    ],
  },
];

export default function Pricing() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const upiId = 'yourupi@paytm'; // placeholder

  return (
    <section id="pricing" className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-warning/30 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-warning/10 border border-warning/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-warning" />
            <span className="text-sm font-medium text-warning">Premium Plans</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text-fire">Choose Your Plan</span>
          </h2>
          <p className="text-text-dim max-w-xl mx-auto text-lg">
            Get premium access with UPI payment — instant activation via bot
          </p>
        </motion.div>

        {/* Plans */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 mb-16">
          {plans.map((plan, i) => {
            const Icon = plan.icon;
            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: i * 0.15 }}
                whileHover={{ y: -8 }}
                className={`relative bg-card/80 backdrop-blur-sm border ${
                  plan.popular ? 'border-primary' : plan.borderColor
                } rounded-3xl p-8 overflow-hidden ${plan.popular ? 'glow-primary' : ''}`}
              >
                {/* Popular badge */}
                {plan.popular && (
                  <div className="absolute top-0 right-0">
                    <div className="bg-gradient-to-r from-primary to-accent text-white text-xs font-bold px-4 py-1 rounded-bl-xl">
                      MOST POPULAR
                    </div>
                  </div>
                )}

                {/* Icon */}
                <div
                  className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-6 shadow-lg`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>

                {/* Plan info */}
                <h3 className="text-xl font-bold text-white mb-1">{plan.name}</h3>
                <p className="text-sm text-text-dim mb-4">{plan.duration} access</p>

                {/* Price */}
                <div className="flex items-baseline gap-1 mb-6">
                  <IndianRupee className="w-6 h-6 text-warning" />
                  <span className="text-5xl font-black text-white">{plan.price}</span>
                  <span className="text-text-dim">/{plan.duration.split(' ')[1].toLowerCase()}</span>
                </div>

                {/* Features */}
                <ul className="space-y-3 mb-8">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-sm text-text-dim">
                      <Check className="w-4 h-4 text-success shrink-0 mt-0.5" />
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>

                {/* CTA */}
                <motion.button
                  onClick={() => setSelectedPlan(selectedPlan === plan.name ? null : plan.name)}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className={`w-full py-3 rounded-xl font-semibold text-sm transition-all ${
                    plan.popular
                      ? 'bg-gradient-to-r from-primary to-accent text-white'
                      : 'bg-card-hover border border-border text-white hover:border-primary'
                  }`}
                >
                  {selectedPlan === plan.name ? 'Hide QR Code' : 'Pay with UPI'}
                </motion.button>

                {/* QR Code */}
                {selectedPlan === plan.name && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-6 text-center"
                  >
                    <div className="qr-container inline-block">
                      <QRCodeSVG
                        value={`upi://pay?pa=${upiId}&pn=SRC%20Bot&am=${plan.price}&cu=INR&tn=SRC%20Bot%20${plan.name}%20Plan`}
                        size={160}
                        level="H"
                        bgColor="#ffffff"
                        fgColor="#0a0a1a"
                      />
                    </div>
                    <p className="text-xs text-text-dim mt-3">
                      Scan with any UPI app to pay ₹{plan.price}
                    </p>
                    <p className="text-xs text-accent mt-1">
                      Send screenshot to bot for activation
                    </p>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Contact */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <p className="text-text-dim">
            Need a custom plan?{' '}
            <a
              href="https://t.me/AKASHH955956"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-light hover:text-accent transition-colors font-semibold"
            >
              Contact @AKASHH955956
            </a>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
