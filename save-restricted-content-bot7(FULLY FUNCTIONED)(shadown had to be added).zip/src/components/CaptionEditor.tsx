import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Type, Replace, Trash2, Eye, EyeOff, Plus, X,
  Sparkles, AlignLeft, AlignRight, Link2, Quote
} from 'lucide-react';

interface ReplaceItem {
  id: number;
  find: string;
  replace: string;
}

interface DeleteItem {
  id: number;
  word: string;
}

interface SpoilerItem {
  id: number;
  text: string;
}

export default function CaptionEditor() {
  const [replaceItems, setReplaceItems] = useState<ReplaceItem[]>([
    { id: 1, find: '@OldChannel', replace: '@MyChannel' },
    { id: 2, find: 'Join Now', replace: '🔥 Subscribe' },
  ]);
  const [deleteItems, setDeleteItems] = useState<DeleteItem[]>([
    { id: 1, word: 'Watermark' },
    { id: 2, word: 'Advertisement' },
  ]);
  const [spoilerItems, setSpoilerItems] = useState<SpoilerItem[]>([
    { id: 1, text: 'Download Link' },
    { id: 2, text: 'Password' },
  ]);
  const [prefix, setPrefix] = useState('📌 ');
  const [suffix, setSuffix] = useState('\n\n🔗 @MyChannel');
  const [activeTab, setActiveTab] = useState<'replace' | 'delete' | 'spoiler' | 'prefix'>('replace');

  const previewCaption = `📌 Hey everyone! Check out this amazing video from @MyChannel 🔥 Subscribe\n\nThe ||Download Link|| is below.\n||Password||: secret123\n\n🔗 @MyChannel`;

  const addReplace = () => {
    setReplaceItems(prev => [...prev, { id: Date.now(), find: '', replace: '' }]);
  };

  const addDelete = () => {
    setDeleteItems(prev => [...prev, { id: Date.now(), word: '' }]);
  };

  const addSpoiler = () => {
    setSpoilerItems(prev => [...prev, { id: Date.now(), text: '' }]);
  };

  const removeReplace = (id: number) => {
    setReplaceItems(prev => prev.filter(item => item.id !== id));
  };

  const removeDelete = (id: number) => {
    setDeleteItems(prev => prev.filter(item => item.id !== id));
  };

  const removeSpoiler = (id: number) => {
    setSpoilerItems(prev => prev.filter(item => item.id !== id));
  };

  return (
    <section id="caption" className="relative py-20 lg:py-28">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-warning/30 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-warning/10 border border-warning/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-warning" />
            <span className="text-sm font-medium text-warning">Advanced Caption Control</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Caption Editor</span>
          </h2>
          <p className="text-text-dim text-lg max-w-2xl mx-auto">
            Replace words, delete unwanted text, add spoiler effects, and customize with prefix/suffix
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-6"
        >
          {/* Editor Panel */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-warning/80 to-orange-500/80 p-4 flex items-center gap-2">
              <Type className="w-5 h-5 text-white" />
              <span className="text-white font-bold">Caption Modification Settings</span>
            </div>

            {/* Tabs */}
            <div className="flex border-b border-border">
              {[
                { key: 'replace', label: 'Replace', icon: Replace, count: replaceItems.length },
                { key: 'delete', label: 'Delete', icon: Trash2, count: deleteItems.length },
                { key: 'spoiler', label: 'Spoiler', icon: EyeOff, count: spoilerItems.length },
                { key: 'prefix', label: 'Prefix/Suffix', icon: AlignLeft, count: 0 },
              ].map(tab => (
                <button
                  key={tab.key}
                  onClick={() => setActiveTab(tab.key as typeof activeTab)}
                  className={`flex-1 px-3 py-3 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 ${
                    activeTab === tab.key
                      ? 'bg-card-hover text-white border-b-2 border-warning'
                      : 'text-text-dim hover:text-white hover:bg-darker/50'
                  }`}
                >
                  <tab.icon className="w-3.5 h-3.5" />
                  {tab.label}
                  {tab.count > 0 && (
                    <span className="px-1.5 py-0.5 bg-warning/20 text-warning text-[10px] rounded-full">
                      {tab.count}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Tab content */}
            <div className="p-4 min-h-[350px]">
              <AnimatePresence mode="wait">
                {/* Replace Tab */}
                {activeTab === 'replace' && (
                  <motion.div
                    key="replace"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-3"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-text-dim">Replace specific words/sentences</p>
                      <motion.button
                        onClick={addReplace}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-1 px-3 py-1.5 bg-success/20 border border-success/30 text-success text-xs font-bold rounded-lg"
                      >
                        <Plus className="w-3 h-3" />
                        Add Replace
                      </motion.button>
                    </div>

                    {replaceItems.map((item, idx) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 bg-darker/50 border border-border/50 rounded-xl"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs text-text-dim font-mono">Replace #{idx + 1}</span>
                          <motion.button
                            onClick={() => removeReplace(item.id)}
                            whileHover={{ scale: 1.1 }}
                            whileTap={{ scale: 0.9 }}
                            className="p-1.5 bg-danger/20 text-danger rounded-lg hover:bg-danger/30"
                          >
                            <X className="w-3 h-3" />
                          </motion.button>
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[10px] text-text-dim uppercase tracking-wider">Find</label>
                            <input
                              type="text"
                              value={item.find}
                              onChange={(e) => setReplaceItems(prev => 
                                prev.map(i => i.id === item.id ? { ...i, find: e.target.value } : i)
                              )}
                              className="w-full mt-1 px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-warning"
                              placeholder="Text to find..."
                            />
                          </div>
                          <div>
                            <label className="text-[10px] text-text-dim uppercase tracking-wider">Replace with</label>
                            <input
                              type="text"
                              value={item.replace}
                              onChange={(e) => setReplaceItems(prev => 
                                prev.map(i => i.id === item.id ? { ...i, replace: e.target.value } : i)
                              )}
                              className="w-full mt-1 px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-success"
                              placeholder="Replacement..."
                            />
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </motion.div>
                )}

                {/* Delete Tab */}
                {activeTab === 'delete' && (
                  <motion.div
                    key="delete"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-3"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-text-dim">Delete specific words/sentences</p>
                      <motion.button
                        onClick={addDelete}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-1 px-3 py-1.5 bg-danger/20 border border-danger/30 text-danger text-xs font-bold rounded-lg"
                      >
                        <Plus className="w-3 h-3" />
                        Add Delete
                      </motion.button>
                    </div>

                    {deleteItems.map((item, idx) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 bg-darker/50 border border-danger/20 rounded-xl flex items-center gap-3"
                      >
                        <Trash2 className="w-4 h-4 text-danger shrink-0" />
                        <div className="flex-1">
                          <label className="text-[10px] text-text-dim uppercase tracking-wider">Delete Word #{idx + 1}</label>
                          <input
                            type="text"
                            value={item.word}
                            onChange={(e) => setDeleteItems(prev => 
                              prev.map(i => i.id === item.id ? { ...i, word: e.target.value } : i)
                            )}
                            className="w-full mt-1 px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-danger"
                            placeholder="Word to delete..."
                          />
                        </div>
                        <motion.button
                          onClick={() => removeDelete(item.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-2 bg-danger/20 text-danger rounded-lg hover:bg-danger/30"
                        >
                          <X className="w-4 h-4" />
                        </motion.button>
                      </motion.div>
                    ))}
                  </motion.div>
                )}

                {/* Spoiler Tab */}
                {activeTab === 'spoiler' && (
                  <motion.div
                    key="spoiler"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-3"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-xs text-text-dim">Add spoiler effect to specific text</p>
                      <motion.button
                        onClick={addSpoiler}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-1 px-3 py-1.5 bg-purple-500/20 border border-purple-500/30 text-purple-400 text-xs font-bold rounded-lg"
                      >
                        <Plus className="w-3 h-3" />
                        Add Spoiler
                      </motion.button>
                    </div>

                    <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl mb-4">
                      <p className="text-xs text-purple-400 flex items-center gap-2">
                        <EyeOff className="w-4 h-4" />
                        Spoiler text appears as ||hidden text|| in Telegram
                      </p>
                    </div>

                    {spoilerItems.map((item, idx) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 bg-darker/50 border border-purple-500/20 rounded-xl flex items-center gap-3"
                      >
                        <Eye className="w-4 h-4 text-purple-400 shrink-0" />
                        <div className="flex-1">
                          <label className="text-[10px] text-text-dim uppercase tracking-wider">Spoiler Text #{idx + 1}</label>
                          <input
                            type="text"
                            value={item.text}
                            onChange={(e) => setSpoilerItems(prev => 
                              prev.map(i => i.id === item.id ? { ...i, text: e.target.value } : i)
                            )}
                            className="w-full mt-1 px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-purple-500"
                            placeholder="Text to hide as spoiler..."
                          />
                        </div>
                        <motion.button
                          onClick={() => removeSpoiler(item.id)}
                          whileHover={{ scale: 1.1 }}
                          whileTap={{ scale: 0.9 }}
                          className="p-2 bg-danger/20 text-danger rounded-lg hover:bg-danger/30"
                        >
                          <X className="w-4 h-4" />
                        </motion.button>
                      </motion.div>
                    ))}
                  </motion.div>
                )}

                {/* Prefix/Suffix Tab */}
                {activeTab === 'prefix' && (
                  <motion.div
                    key="prefix"
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4"
                  >
                    <div className="p-4 bg-darker/50 border border-border/50 rounded-xl">
                      <div className="flex items-center gap-2 mb-3">
                        <AlignLeft className="w-4 h-4 text-blue-400" />
                        <label className="text-sm font-semibold text-white">Prefix (Start of caption)</label>
                      </div>
                      <input
                        type="text"
                        value={prefix}
                        onChange={(e) => setPrefix(e.target.value)}
                        className="w-full px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-blue-500"
                        placeholder="Add text at the beginning..."
                      />
                    </div>

                    <div className="p-4 bg-darker/50 border border-border/50 rounded-xl">
                      <div className="flex items-center gap-2 mb-3">
                        <AlignRight className="w-4 h-4 text-green-400" />
                        <label className="text-sm font-semibold text-white">Suffix (End of caption)</label>
                      </div>
                      <textarea
                        value={suffix}
                        onChange={(e) => setSuffix(e.target.value)}
                        rows={3}
                        className="w-full px-3 py-2 bg-darker border border-border rounded-lg text-sm text-white placeholder:text-text-dim focus:outline-none focus:border-green-500 resize-none"
                        placeholder="Add text at the end..."
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <button className="p-3 bg-cyan-500/20 border border-cyan-500/30 rounded-xl text-xs font-bold text-cyan-400 flex items-center justify-center gap-2 hover:bg-cyan-500/30 transition-colors">
                        <Link2 className="w-4 h-4" />
                        Add Hyperlink
                      </button>
                      <button className="p-3 bg-amber-500/20 border border-amber-500/30 rounded-xl text-xs font-bold text-amber-400 flex items-center justify-center gap-2 hover:bg-amber-500/30 transition-colors">
                        <Quote className="w-4 h-4" />
                        Add Quote Effect
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Save button */}
            <div className="p-4 border-t border-border">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="w-full py-3 bg-gradient-to-r from-warning to-orange-500 text-white font-bold rounded-xl"
              >
                💾 Save Caption Settings
              </motion.button>
            </div>
          </div>

          {/* Preview Panel */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden">
            <div className="bg-darker p-4 flex items-center gap-2 border-b border-border">
              <Eye className="w-5 h-5 text-text-dim" />
              <span className="text-white font-bold">Live Preview</span>
            </div>

            <div className="p-6">
              <div className="mb-4 p-3 bg-darker/50 border border-border/50 rounded-xl">
                <p className="text-xs text-text-dim mb-2">Original Caption:</p>
                <p className="text-sm text-text font-mono">
                  Hey everyone! Check out this amazing video from @OldChannel Join Now
                  <br /><br />
                  The Download Link is below.
                  <br />
                  Password: secret123
                </p>
              </div>

              <div className="flex items-center gap-2 my-4">
                <div className="flex-1 h-px bg-border" />
                <span className="text-xs text-text-dim">After modifications</span>
                <div className="flex-1 h-px bg-border" />
              </div>

              <div className="p-4 bg-telegram/10 border border-telegram/20 rounded-xl">
                <p className="text-xs text-telegram mb-2">Modified Caption:</p>
                <p className="text-sm text-white font-mono whitespace-pre-line">
                  {previewCaption}
                </p>
              </div>

              <div className="mt-4 space-y-2">
                <div className="flex items-center gap-2 text-xs">
                  <Replace className="w-3 h-3 text-warning" />
                  <span className="text-text-dim">
                    <span className="text-danger line-through">@OldChannel</span> → <span className="text-success">@MyChannel</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <Replace className="w-3 h-3 text-warning" />
                  <span className="text-text-dim">
                    <span className="text-danger line-through">Join Now</span> → <span className="text-success">🔥 Subscribe</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <EyeOff className="w-3 h-3 text-purple-400" />
                  <span className="text-text-dim">
                    "Download Link" → <span className="text-purple-400">||Download Link||</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <EyeOff className="w-3 h-3 text-purple-400" />
                  <span className="text-text-dim">
                    "Password" → <span className="text-purple-400">||Password||</span>
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <AlignLeft className="w-3 h-3 text-blue-400" />
                  <span className="text-text-dim">
                    Prefix: <span className="text-blue-400">📌 </span>
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <AlignRight className="w-3 h-3 text-green-400" />
                  <span className="text-text-dim">
                    Suffix: <span className="text-green-400">🔗 @MyChannel</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
