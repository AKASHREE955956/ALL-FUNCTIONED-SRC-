import { motion } from 'framer-motion';
import { Terminal, Sparkles } from 'lucide-react';

const commands = [
  { cmd: '/start', desc: 'Start the bot & see welcome message', category: 'Basic' },
  { cmd: '/help', desc: 'Show all available commands', category: 'Basic' },
  { cmd: '/login', desc: 'Login with mobile/session', category: 'Auth' },
  { cmd: '/logout', desc: 'Logout and delete session', category: 'Auth' },
  { cmd: '/single <link>', desc: 'Download a single link', category: 'Download' },
  { cmd: '/batch <start> <end>', desc: 'Download multiple links at once', category: 'Download' },
  { cmd: '/setdest <channel>', desc: 'Set forwarding destination', category: 'Config' },
  { cmd: '/setdelay <seconds>', desc: 'Set delay between uploads', category: 'Config' },
  { cmd: '/caption', desc: 'Configure caption modifications', category: 'Config' },
  { cmd: '/status', desc: 'Check current task status', category: 'Info' },
  { cmd: '/myplan', desc: 'View your premium plan info', category: 'Info' },
  { cmd: '/admin', desc: 'Open admin panel (admin only)', category: 'Admin' },
  { cmd: '/broadcast <msg>', desc: 'Send message to all users', category: 'Admin' },
  { cmd: '/givepremium <id>', desc: 'Give premium to a user', category: 'Admin' },
  { cmd: '/ban <id>', desc: 'Ban a user from the bot', category: 'Admin' },
  { cmd: '/setprice', desc: 'Configure plan pricing', category: 'Admin' },
];

const categoryColors: Record<string, string> = {
  Basic: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  Auth: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  Download: 'bg-green-500/20 text-green-400 border-green-500/30',
  Config: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  Info: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  Admin: 'bg-red-500/20 text-red-400 border-red-500/30',
};

export default function Commands() {
  return (
    <section className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 border border-primary/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-primary-light" />
            <span className="text-sm font-medium text-primary-light">Command Reference</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Bot Commands</span>
          </h2>
          <p className="text-text-dim text-lg">
            All commands available in the bot — admin commands require owner access
          </p>
        </motion.div>

        {/* Commands table */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="bg-card border border-border rounded-2xl overflow-hidden"
        >
          {/* Terminal header */}
          <div className="bg-darker flex items-center gap-3 px-4 py-3 border-b border-border">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/80" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
              <div className="w-3 h-3 rounded-full bg-green-500/80" />
            </div>
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-text-dim" />
              <span className="text-sm text-text-dim font-mono">commands.sh</span>
            </div>
          </div>

          {/* Commands list */}
          <div className="divide-y divide-border/50">
            {commands.map((cmd, i) => (
              <motion.div
                key={cmd.cmd}
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.03 }}
                className="flex items-center gap-4 px-6 py-3 hover:bg-card-hover transition-colors"
              >
                <code className="text-sm font-mono text-accent font-semibold min-w-[200px]">
                  {cmd.cmd}
                </code>
                <span className="flex-1 text-sm text-text-dim">{cmd.desc}</span>
                <span
                  className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${
                    categoryColors[cmd.category]
                  }`}
                >
                  {cmd.category}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
