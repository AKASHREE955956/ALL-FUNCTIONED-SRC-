import { motion } from 'framer-motion';
import { Shield, Heart, ExternalLink, MessageCircle, Zap } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="relative border-t border-border bg-darker/50">
      {/* CTA Banner */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="relative bg-gradient-to-r from-primary to-accent rounded-3xl p-8 lg:p-12 text-center overflow-hidden"
        >
          {/* Background pattern */}
          <div className="absolute inset-0 grid-bg opacity-10" />
          
          <div className="relative z-10">
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
            >
              <Shield className="w-12 h-12 text-white mx-auto mb-4" />
            </motion.div>
            <h3 className="text-2xl lg:text-3xl font-black text-white mb-4">
              Ready to Save Restricted Content?
            </h3>
            <p className="text-white/80 max-w-lg mx-auto mb-8">
              Get started with premium access today. Pay via UPI, get instant activation, 
              and start downloading from any private channel or group.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <motion.a
                href="https://t.me/AKASHH955956"
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 bg-white text-primary font-bold rounded-xl flex items-center gap-2 shadow-lg"
              >
                <MessageCircle className="w-5 h-5" />
                Contact @AKASHH955956
              </motion.a>
              <motion.a
                href="#pricing"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-8 py-3 border-2 border-white/30 text-white font-semibold rounded-xl flex items-center gap-2 hover:bg-white/10 transition-colors"
              >
                <Zap className="w-5 h-5" />
                View Plans
              </motion.a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Footer content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-lg font-bold gradient-text">SRC Bot</span>
                <span className="block text-[10px] text-text-dim tracking-widest uppercase">
                  Save Restricted Content
                </span>
              </div>
            </div>
            <p className="text-sm text-text-dim leading-relaxed max-w-md">
              The most powerful Telegram bot for saving restricted content from private 
              channels, groups, and super groups. Encrypted, fast, and reliable.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Quick Links
            </h4>
            <ul className="space-y-2">
              {['Features', 'How It Works', 'Pricing', 'Admin Panel', 'Demo'].map((link) => (
                <li key={link}>
                  <a
                    href={`#${link.toLowerCase().replace(/ /g, '-')}`}
                    className="text-sm text-text-dim hover:text-white transition-colors flex items-center gap-1"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-sm font-bold text-white mb-4 uppercase tracking-wider">
              Contact
            </h4>
            <ul className="space-y-2">
              <li>
                <a
                  href="https://t.me/AKASHH955956"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-sm text-text-dim hover:text-telegram transition-colors flex items-center gap-2"
                >
                  <ExternalLink className="w-3 h-3" />
                  @AKASHH955956
                </a>
              </li>
              <li className="text-sm text-text-dim">
                Telegram Bot Support
              </li>
              <li className="text-sm text-text-dim">
                Premium & Custom Plans
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-border pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs text-text-dim flex items-center gap-1">
            © 2025 SRC Bot. Made with
            <Heart className="w-3 h-3 text-danger" />
            for Telegram users
          </p>
          <div className="flex items-center gap-4">
            <span className="text-xs text-text-dim">
              Powered by Pyrogram & Telethon
            </span>
            <div className="flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
              <span className="text-xs text-success font-semibold">Online</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
