import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Download, HardDrive, Clock, FileVideo, Gauge,
  CheckCircle, Sparkles, StopCircle, Play, Pin,
  Forward, FileText, Image, Music, File
} from 'lucide-react';

interface FileProgress {
  id: number;
  name: string;
  size: string;
  type: 'video' | 'image' | 'audio' | 'document' | 'file';
  progress: number;
  speed: number;
  status: 'pending' | 'downloading' | 'forwarding' | 'done' | 'stopped';
  isPinned?: boolean;
}

const initialFiles: Omit<FileProgress, 'progress' | 'speed' | 'status'>[] = [
  { id: 1, name: 'intro_video.mp4', size: '245 MB', type: 'video', isPinned: true },
  { id: 2, name: 'lecture_notes.pdf', size: '12 MB', type: 'document' },
  { id: 3, name: 'background_music.mp3', size: '8.5 MB', type: 'audio' },
  { id: 4, name: 'banner_image.jpg', size: '4.2 MB', type: 'image' },
  { id: 5, name: 'tutorial_part1.mp4', size: '512 MB', type: 'video' },
  { id: 6, name: 'resources.zip', size: '156 MB', type: 'file' },
  { id: 7, name: 'chapter_02.mp4', size: '324 MB', type: 'video' },
  { id: 8, name: 'slides_deck.pdf', size: '28 MB', type: 'document' },
  { id: 9, name: 'preview_clip.mp4', size: '89 MB', type: 'video' },
  { id: 10, name: 'final_summary.pdf', size: '5.1 MB', type: 'document' },
];

const getFileIcon = (type: string) => {
  switch (type) {
    case 'video': return FileVideo;
    case 'image': return Image;
    case 'audio': return Music;
    case 'document': return FileText;
    default: return File;
  }
};

const getTypeColor = (type: string) => {
  switch (type) {
    case 'video': return 'text-purple-400 bg-purple-500/20';
    case 'image': return 'text-pink-400 bg-pink-500/20';
    case 'audio': return 'text-green-400 bg-green-500/20';
    case 'document': return 'text-blue-400 bg-blue-500/20';
    default: return 'text-gray-400 bg-gray-500/20';
  }
};

export default function ProgressDemo() {
  const [files, setFiles] = useState<FileProgress[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [totalStats, setTotalStats] = useState({ completed: 0, totalSpeed: 0 });

  const initFiles = useCallback(() => {
    setFiles(initialFiles.map(f => ({ ...f, progress: 0, speed: 0, status: 'pending' })));
  }, []);

  useEffect(() => {
    initFiles();
  }, [initFiles]);

  useEffect(() => {
    if (!isRunning || isPaused) return;

    const interval = setInterval(() => {
      setFiles(prev => {
        const updated = [...prev];
        let activeFound = false;
        let completed = 0;
        let totalSpeed = 0;

        for (let i = 0; i < updated.length; i++) {
          const file = updated[i];
          
          if (file.status === 'done' || file.status === 'stopped') {
            if (file.status === 'done') completed++;
            continue;
          }

          if (!activeFound) {
            activeFound = true;
            
            if (file.status === 'pending') {
              updated[i] = { ...file, status: 'downloading', speed: Math.random() * 15 + 8 };
            } else if (file.status === 'downloading') {
              const newProgress = Math.min(100, file.progress + Math.random() * 4 + 2);
              const newSpeed = Math.random() * 15 + 8;
              totalSpeed = newSpeed;
              
              if (newProgress >= 100) {
                updated[i] = { ...file, progress: 100, speed: 0, status: 'forwarding' };
              } else {
                updated[i] = { ...file, progress: newProgress, speed: newSpeed };
              }
            } else if (file.status === 'forwarding') {
              updated[i] = { ...file, status: 'done' };
              completed++;
            }
          }
        }

        setTotalStats({ completed, totalSpeed });

        // Check if all done
        if (updated.every(f => f.status === 'done' || f.status === 'stopped')) {
          setIsRunning(false);
        }

        return updated;
      });
    }, 150);

    return () => clearInterval(interval);
  }, [isRunning, isPaused]);

  const startBatch = () => {
    initFiles();
    setIsRunning(true);
    setIsPaused(false);
  };

  const stopBatch = () => {
    setIsRunning(false);
    setFiles(prev => prev.map(f => 
      f.status === 'pending' || f.status === 'downloading' || f.status === 'forwarding'
        ? { ...f, status: 'stopped' }
        : f
    ));
  };

  const currentFile = files.find(f => f.status === 'downloading' || f.status === 'forwarding');
  const eta = currentFile ? Math.round((100 - currentFile.progress) / (currentFile.speed || 1) * 2) : 0;

  return (
    <section className="relative py-20 lg:py-28">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-accent/10 border border-accent/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">Real-Time Tracking</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Multi-File Progress</span>
          </h2>
          <p className="text-text-dim text-lg">
            Watch individual progress for each file with speed, ETA, and status
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="grid grid-cols-1 lg:grid-cols-3 gap-6"
        >
          {/* File List Panel */}
          <div className="lg:col-span-2 bg-card border border-border rounded-2xl overflow-hidden">
            {/* Header bar */}
            <div className="bg-gradient-to-r from-primary to-accent p-4 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Download className="w-5 h-5 text-white" />
                <span className="text-white font-bold">Batch Download — 10 Links</span>
              </div>
              <span className="text-white/80 text-sm font-mono">
                {totalStats.completed}/{files.length} done
              </span>
            </div>

            {/* Inline Keyboard - Stop Button */}
            <div className="px-4 py-3 bg-darker/50 border-b border-border/50">
              <div className="flex items-center gap-2">
                <span className="text-xs text-text-dim">Bot Controls:</span>
                <div className="flex gap-2">
                  {!isRunning ? (
                    <motion.button
                      onClick={startBatch}
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                      className="flex items-center gap-1.5 px-4 py-2 bg-success/20 border border-success/30 text-success text-xs font-bold rounded-lg hover:bg-success/30 transition-colors"
                    >
                      <Play className="w-3.5 h-3.5" />
                      ▶️ Start Batch
                    </motion.button>
                  ) : (
                    <>
                      <motion.button
                        onClick={() => setIsPaused(!isPaused)}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-1.5 px-4 py-2 bg-warning/20 border border-warning/30 text-warning text-xs font-bold rounded-lg hover:bg-warning/30 transition-colors"
                      >
                        {isPaused ? '▶️ Resume' : '⏸️ Pause'}
                      </motion.button>
                      <motion.button
                        onClick={stopBatch}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="flex items-center gap-1.5 px-4 py-2 bg-danger/20 border border-danger/30 text-danger text-xs font-bold rounded-lg hover:bg-danger/30 transition-colors"
                      >
                        <StopCircle className="w-3.5 h-3.5" />
                        🛑 Stop Batch
                      </motion.button>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Files list */}
            <div className="p-3 max-h-[450px] overflow-y-auto space-y-2">
              <AnimatePresence>
                {files.map((file, idx) => {
                  const Icon = getFileIcon(file.type);
                  const typeColor = getTypeColor(file.type);
                  
                  return (
                    <motion.div
                      key={file.id}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: idx * 0.03 }}
                      className={`relative p-3 rounded-xl border transition-all ${
                        file.status === 'downloading' || file.status === 'forwarding'
                          ? 'bg-primary/10 border-primary/30'
                          : file.status === 'done'
                          ? 'bg-success/5 border-success/20'
                          : file.status === 'stopped'
                          ? 'bg-danger/5 border-danger/20'
                          : 'bg-darker/50 border-border/30'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {/* File icon */}
                        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${typeColor}`}>
                          <Icon className="w-5 h-5" />
                        </div>

                        {/* File info */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-semibold text-white truncate">
                              {file.name}
                            </span>
                            {file.isPinned && (
                              <span className="flex items-center gap-1 px-1.5 py-0.5 bg-warning/20 text-warning text-[10px] font-bold rounded">
                                <Pin className="w-2.5 h-2.5" />
                                PINNED
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-3 mt-1">
                            <span className="text-xs text-text-dim">{file.size}</span>
                            {file.status === 'downloading' && (
                              <>
                                <span className="text-xs text-accent font-mono">
                                  ⚡ {file.speed.toFixed(1)} MB/s
                                </span>
                                <span className="text-xs text-warning font-mono">
                                  ⏱️ ~{Math.round((100 - file.progress) / file.speed * 2)}s
                                </span>
                              </>
                            )}
                            {file.status === 'forwarding' && (
                              <span className="text-xs text-purple-400 flex items-center gap-1">
                                <Forward className="w-3 h-3" />
                                Forwarding to destination...
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Status/Progress */}
                        <div className="text-right">
                          {file.status === 'pending' && (
                            <span className="text-xs text-text-dim">Waiting...</span>
                          )}
                          {file.status === 'downloading' && (
                            <span className="text-lg font-bold text-primary-light">
                              {Math.round(file.progress)}%
                            </span>
                          )}
                          {file.status === 'forwarding' && (
                            <motion.div
                              animate={{ rotate: 360 }}
                              transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                            >
                              <Forward className="w-5 h-5 text-purple-400" />
                            </motion.div>
                          )}
                          {file.status === 'done' && (
                            <CheckCircle className="w-5 h-5 text-success" />
                          )}
                          {file.status === 'stopped' && (
                            <StopCircle className="w-5 h-5 text-danger" />
                          )}
                        </div>
                      </div>

                      {/* Progress bar */}
                      {(file.status === 'downloading' || file.status === 'forwarding') && (
                        <div className="mt-2 h-1.5 bg-darker rounded-full overflow-hidden">
                          <motion.div
                            className={`h-full rounded-full ${
                              file.status === 'forwarding' 
                                ? 'bg-gradient-to-r from-purple-500 to-pink-500' 
                                : 'bg-gradient-to-r from-primary to-accent'
                            }`}
                            style={{ width: `${file.progress}%` }}
                          />
                        </div>
                      )}
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          </div>

          {/* Stats Panel */}
          <div className="space-y-4">
            {/* Current file stats */}
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="text-sm font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
                <Gauge className="w-4 h-4" />
                Current File Stats
              </h3>
              
              {currentFile ? (
                <div className="space-y-4">
                  <div className="p-3 bg-darker/50 rounded-xl">
                    <p className="text-xs text-text-dim mb-1">Currently Processing</p>
                    <p className="text-sm font-semibold text-white truncate">{currentFile.name}</p>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 bg-darker/50 rounded-xl text-center">
                      <Gauge className="w-4 h-4 text-accent mx-auto mb-1" />
                      <p className="text-xl font-bold text-white">{currentFile.speed.toFixed(1)}</p>
                      <p className="text-[10px] text-text-dim">MB/s</p>
                    </div>
                    <div className="p-3 bg-darker/50 rounded-xl text-center">
                      <Clock className="w-4 h-4 text-warning mx-auto mb-1" />
                      <p className="text-xl font-bold text-white">{eta}s</p>
                      <p className="text-[10px] text-text-dim">ETA</p>
                    </div>
                  </div>

                  <div className="p-3 bg-darker/50 rounded-xl">
                    <div className="flex justify-between text-xs mb-2">
                      <span className="text-text-dim">Progress</span>
                      <span className="text-white font-bold">{Math.round(currentFile.progress)}%</span>
                    </div>
                    <div className="h-2 bg-darker rounded-full overflow-hidden">
                      <motion.div
                        className="h-full bg-gradient-to-r from-primary via-accent to-primary-light"
                        style={{ width: `${currentFile.progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-text-dim text-sm">
                  {isRunning ? 'Processing...' : 'Click Start to begin'}
                </div>
              )}
            </div>

            {/* Overall stats */}
            <div className="bg-card border border-border rounded-2xl p-5">
              <h3 className="text-sm font-bold text-text-dim uppercase tracking-wider mb-4 flex items-center gap-2">
                <HardDrive className="w-4 h-4" />
                Batch Progress
              </h3>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-text-dim">Completed</span>
                  <span className="text-lg font-bold text-success">{totalStats.completed}/{files.length}</span>
                </div>
                <div className="h-2 bg-darker rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-success to-accent"
                    style={{ width: `${(totalStats.completed / files.length) * 100}%` }}
                  />
                </div>
                
                {files.some(f => f.isPinned && f.status === 'done') && (
                  <div className="mt-3 p-2 bg-warning/10 border border-warning/20 rounded-lg">
                    <p className="text-xs text-warning flex items-center gap-1">
                      <Pin className="w-3 h-3" />
                      Pinned message will be pinned in destination
                    </p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
