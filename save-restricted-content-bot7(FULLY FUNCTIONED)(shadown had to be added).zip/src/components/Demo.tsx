import { useState, useEffect, useRef, memo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Bot, User, Loader2, StopCircle, Play, Pin } from 'lucide-react';

interface Message {
  id: number;
  from: 'user' | 'bot';
  text: string;
  typing?: boolean;
  hasButtons?: boolean;
  hasPinned?: boolean;
}

const demoFlow: Omit<Message, 'id'>[] = [
  { from: 'user', text: '/start' },
  { from: 'bot', text: '🤖 Welcome to SRC Bot!\n\n🔐 Your session is encrypted.\n📌 Use /login to start.\n📌 Use /help for commands.' },
  { from: 'user', text: '/batch https://t.me/c/12345/1 https://t.me/c/12345/10' },
  { from: 'bot', text: '📥 Batch Started!\n━━━━━━━━━━━━━━━━━\n📊 Total: 10 files\n⏱️ Est: ~2 min', hasButtons: true },
  { from: 'bot', text: '📥 [1/10] intro.mp4\n████████░░ 80%\n⚡ 15.2 MB/s | ⏱️ 12s', hasPinned: true },
  { from: 'bot', text: '📌 Pinned message detected!\nWill auto-pin in destination.' },
  { from: 'bot', text: '✅ Batch Complete!\n━━━━━━━━━━━━━━━━━\n📊 10/10 done\n📤 Forwarded to @YourChannel\n📌 1 message auto-pinned\n⏱️ Time: 1m 45s' },
];

const Demo = memo(function Demo() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const runDemo = () => {
    setMessages([]);
    setCurrentIndex(0);
    setIsRunning(true);
  };

  useEffect(() => {
    if (!isRunning || currentIndex >= demoFlow.length) {
      if (currentIndex >= demoFlow.length) setIsRunning(false);
      return;
    }

    const msg = demoFlow[currentIndex];
    // Faster delays
    const delay = msg.from === 'bot' ? 600 : 300;

    if (msg.from === 'bot') {
      const typingTimer = setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: Date.now(), from: 'bot', text: '', typing: true },
        ]);
      }, 100);

      const msgTimer = setTimeout(() => {
        setMessages((prev) => {
          const filtered = prev.filter((m) => !m.typing);
          return [...filtered, { 
            id: Date.now(), 
            from: msg.from, 
            text: msg.text,
            hasButtons: msg.hasButtons,
            hasPinned: msg.hasPinned
          }];
        });
        setCurrentIndex((i) => i + 1);
      }, delay);

      return () => {
        clearTimeout(typingTimer);
        clearTimeout(msgTimer);
      };
    } else {
      const timer = setTimeout(() => {
        setMessages((prev) => [
          ...prev,
          { id: Date.now(), from: msg.from, text: msg.text },
        ]);
        setCurrentIndex((i) => i + 1);
      }, delay);
      return () => clearTimeout(timer);
    }
  }, [isRunning, currentIndex]);

  return (
    <section id="demo" className="relative py-20 lg:py-28">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-10"
        >
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Live Bot Demo</span>
          </h2>
          <p className="text-text-dim text-lg">
            Watch batch download with stop button & auto-pin detection
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative max-w-2xl mx-auto"
        >
          {/* Window chrome */}
          <div className="bg-card border border-border rounded-t-2xl px-4 py-3 flex items-center gap-3">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/80" />
              <div className="w-3 h-3 rounded-full bg-yellow-500/80" />
              <div className="w-3 h-3 rounded-full bg-green-500/80" />
            </div>
            <div className="flex-1 flex items-center justify-center gap-2">
              <Bot className="w-4 h-4 text-telegram" />
              <span className="text-sm font-semibold text-white">SRC Bot</span>
            </div>
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="w-2 h-2 rounded-full bg-success"
            />
          </div>

          {/* Chat area */}
          <div className="bg-darker/80 border-x border-border h-[400px] overflow-y-auto p-4 space-y-3">
            {messages.length === 0 && !isRunning && (
              <div className="h-full flex flex-col items-center justify-center text-center">
                <Bot className="w-16 h-16 text-text-dim/30 mb-4" />
                <p className="text-text-dim text-sm">Click "Run Demo" to start</p>
              </div>
            )}

            <AnimatePresence>
              {messages.map((msg) => (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2 }}
                  className={`flex ${msg.from === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.typing ? (
                    <div className="msg-bubble-bot px-4 py-3 max-w-xs">
                      <div className="flex items-center gap-1">
                        <Loader2 className="w-4 h-4 text-accent animate-spin" />
                        <span className="text-text-dim text-sm">typing...</span>
                      </div>
                    </div>
                  ) : (
                    <div className={`max-w-sm ${
                      msg.from === 'user'
                        ? 'bg-primary/20 border border-primary/30 rounded-2xl rounded-br-sm px-4 py-3'
                        : ''
                    }`}>
                      {msg.from === 'bot' && (
                        <div className="msg-bubble-bot px-4 py-3">
                          <div className="flex items-center gap-2 mb-1.5">
                            <Bot className="w-3 h-3 text-accent" />
                            <span className="text-[10px] font-bold uppercase tracking-wider text-accent">
                              SRC Bot
                            </span>
                            {msg.hasPinned && (
                              <span className="flex items-center gap-1 px-1.5 py-0.5 bg-warning/20 text-warning text-[8px] font-bold rounded">
                                <Pin className="w-2 h-2" />
                                PINNED
                              </span>
                            )}
                          </div>
                          <p className="text-sm text-text whitespace-pre-line font-mono leading-relaxed">
                            {msg.text}
                          </p>

                          {/* Inline keyboard buttons */}
                          {msg.hasButtons && (
                            <div className="mt-3 grid grid-cols-2 gap-2">
                              <button className="flex items-center justify-center gap-1 px-3 py-2 bg-warning/20 border border-warning/30 rounded-lg text-warning text-xs font-bold">
                                ⏸️ Pause
                              </button>
                              <button className="flex items-center justify-center gap-1 px-3 py-2 bg-danger/20 border border-danger/30 rounded-lg text-danger text-xs font-bold">
                                <StopCircle className="w-3 h-3" />
                                Stop Batch
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {msg.from === 'user' && (
                        <>
                          <div className="flex items-center gap-2 mb-1.5">
                            <User className="w-3 h-3 text-primary-light" />
                            <span className="text-[10px] font-bold uppercase tracking-wider text-primary-light">
                              You
                            </span>
                          </div>
                          <p className="text-sm text-text whitespace-pre-line font-mono">
                            {msg.text}
                          </p>
                        </>
                      )}
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
            <div ref={chatEndRef} />
          </div>

          {/* Bottom bar */}
          <div className="bg-card border border-t-0 border-border rounded-b-2xl px-4 py-3 flex items-center gap-3">
            <motion.button
              onClick={runDemo}
              disabled={isRunning}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
              className={`px-6 py-2.5 rounded-xl font-semibold text-sm flex items-center gap-2 transition-all ${
                isRunning
                  ? 'bg-border text-text-dim cursor-not-allowed'
                  : 'bg-gradient-to-r from-primary to-accent text-white'
              }`}
            >
              {isRunning ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Running...
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Run Demo
                </>
              )}
            </motion.button>
            <div className="flex-1 bg-darker/50 border border-border rounded-xl px-4 py-2 text-sm text-text-dim">
              Type a message...
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

export default Demo;
