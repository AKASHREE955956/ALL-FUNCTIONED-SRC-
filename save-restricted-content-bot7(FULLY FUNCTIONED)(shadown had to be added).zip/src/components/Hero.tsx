import { memo } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, Lock, Zap, Download, Pin, StopCircle } from 'lucide-react';

const Hero = memo(function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      {/* Background */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-15"
        style={{ backgroundImage: 'url(/images/hero-bg.jpg)' }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-darker/50 via-darker/80 to-darker" />
      <div className="absolute inset-0 grid-bg opacity-20" />

      {/* Glowing orbs - simplified */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-primary/10 rounded-full blur-[100px] animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-accent/10 rounded-full blur-[100px] animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 max-w-5xl mx-auto px-4 text-center">
        {/* Badge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="inline-flex items-center gap-2 px-4 py-2 bg-card/80 border border-border rounded-full mb-6"
        >
          <span className="text-sm text-text-dim">
            Most Powerful Telegram Content Saver Bot
          </span>
          <span className="px-2 py-0.5 bg-success/20 text-success text-xs font-bold rounded-full">
            v2.0
          </span>
        </motion.div>

        {/* Title */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-7xl font-black tracking-tight mb-5"
        >
          <span className="gradient-text">Save Restricted</span>
          <br />
          <span className="text-white">Content Bot</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-base sm:text-lg text-text-dim max-w-2xl mx-auto mb-8 leading-relaxed"
        >
          Download & forward content from{' '}
          <span className="text-primary-light font-semibold">private channels</span>,{' '}
          <span className="text-accent font-semibold">restricted groups</span> with
          real-time progress, batch controls, and auto-pin detection.
        </motion.p>

        {/* Feature pills */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="flex flex-wrap justify-center gap-2 mb-10"
        >
          {[
            { icon: Lock, label: 'Encrypted Sessions', color: 'text-primary-light' },
            { icon: Download, label: 'Multi-File Progress', color: 'text-accent' },
            { icon: StopCircle, label: 'Batch Controls', color: 'text-danger' },
            { icon: Pin, label: 'Auto-Pin Detection', color: 'text-warning' },
            { icon: Zap, label: 'Lightning Fast', color: 'text-success' },
          ].map(({ icon: Icon, label, color }) => (
            <div
              key={label}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-card/60 border border-border/50 rounded-full"
            >
              <Icon className={`w-3.5 h-3.5 ${color}`} />
              <span className="text-xs font-medium text-text">{label}</span>
            </div>
          ))}
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-12"
        >
          <motion.a
            href="https://t.me/AKASHH955956"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="group relative px-7 py-3.5 bg-gradient-to-r from-primary to-primary-light text-white font-bold rounded-xl text-base overflow-hidden"
          >
            <span className="relative z-10 flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Get Premium Access
            </span>
          </motion.a>

          <motion.a
            href="#features"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            className="px-7 py-3.5 border-2 border-border hover:border-primary text-text font-semibold rounded-xl text-base transition-colors"
          >
            Explore Features
          </motion.a>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.5 }}
          className="grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-2xl mx-auto"
        >
          {[
            { value: '100%', label: 'Encrypted' },
            { value: '10+', label: 'Files/Batch' },
            { value: '24/7', label: 'Uptime' },
            { value: 'Auto', label: 'Pin Detect' },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl sm:text-3xl font-black gradient-text">
                {stat.value}
              </div>
              <div className="text-[10px] text-text-dim mt-0.5 uppercase tracking-widest">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>

        {/* Scroll indicator */}
        <motion.div
          className="absolute bottom-6 left-1/2 -translate-x-1/2"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ArrowDown className="w-5 h-5 text-text-dim" />
        </motion.div>
      </div>
    </section>
  );
});

export default Hero;
