import { motion } from 'framer-motion';
import { Pin, ArrowRight, CheckCircle, MessageSquare, Forward } from 'lucide-react';

export default function PinnedFeature() {
  return (
    <section className="relative py-16 lg:py-20">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-to-br from-warning/10 to-orange-500/10 border border-warning/20 rounded-3xl p-8 lg:p-10"
        >
          <div className="flex flex-col lg:flex-row items-start gap-8">
            {/* Icon */}
            <motion.div
              animate={{ y: [0, -5, 0] }}
              transition={{ duration: 3, repeat: Infinity }}
              className="w-16 h-16 rounded-2xl bg-gradient-to-br from-warning to-orange-500 flex items-center justify-center shadow-lg shrink-0"
            >
              <Pin className="w-8 h-8 text-white" />
            </motion.div>

            {/* Content */}
            <div className="flex-1">
              <h3 className="text-2xl font-black text-white mb-3">
                Auto-Pin Detection & Forwarding
              </h3>
              <p className="text-text-dim mb-6 leading-relaxed">
                When downloading from a source channel, the bot automatically detects if the message 
                is pinned. After forwarding to your destination, the bot will <strong className="text-warning">automatically 
                pin that message</strong> in your destination channel/group too!
              </p>

              {/* Flow diagram */}
              <div className="flex flex-col sm:flex-row items-stretch gap-4">
                {/* Source */}
                <div className="flex-1 p-4 bg-darker/50 border border-border rounded-xl">
                  <div className="flex items-center gap-2 mb-3">
                    <MessageSquare className="w-4 h-4 text-blue-400" />
                    <span className="text-xs font-bold text-blue-400 uppercase tracking-wider">Source Channel</span>
                  </div>
                  <div className="p-3 bg-card border border-border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Pin className="w-3 h-3 text-warning" />
                      <span className="text-[10px] text-warning font-bold">PINNED MESSAGE</span>
                    </div>
                    <p className="text-xs text-text-dim">📢 Important announcement...</p>
                  </div>
                </div>

                {/* Arrow */}
                <div className="flex items-center justify-center">
                  <motion.div
                    animate={{ x: [0, 8, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    className="hidden sm:flex items-center gap-1"
                  >
                    <ArrowRight className="w-6 h-6 text-accent" />
                    <ArrowRight className="w-6 h-6 text-accent -ml-3" />
                  </motion.div>
                  <motion.div
                    animate={{ y: [0, 8, 0] }}
                    transition={{ duration: 1.5, repeat: Infinity }}
                    className="sm:hidden rotate-90"
                  >
                    <ArrowRight className="w-6 h-6 text-accent" />
                  </motion.div>
                </div>

                {/* Destination */}
                <div className="flex-1 p-4 bg-darker/50 border border-success/20 rounded-xl">
                  <div className="flex items-center gap-2 mb-3">
                    <Forward className="w-4 h-4 text-success" />
                    <span className="text-xs font-bold text-success uppercase tracking-wider">Your Channel</span>
                  </div>
                  <div className="p-3 bg-card border border-success/30 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Pin className="w-3 h-3 text-success" />
                      <span className="text-[10px] text-success font-bold">AUTO-PINNED ✓</span>
                    </div>
                    <p className="text-xs text-text-dim">📢 Important announcement...</p>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="mt-6 flex flex-wrap gap-3">
                {[
                  'Detects pinned messages',
                  'Auto-pins in destination',
                  'Works with topics',
                  'Multiple pins supported'
                ].map((feat) => (
                  <div
                    key={feat}
                    className="flex items-center gap-1.5 px-3 py-1.5 bg-warning/10 border border-warning/20 rounded-full"
                  >
                    <CheckCircle className="w-3 h-3 text-warning" />
                    <span className="text-xs text-warning font-medium">{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
