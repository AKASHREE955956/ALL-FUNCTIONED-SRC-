import { motion } from 'framer-motion';
import {
  Database, Shield,
  ArrowRight, Server, Cloud, Smartphone, Sparkles
} from 'lucide-react';



const topicList = [
  { id: 3, name: 'Session Storage', desc: 'Encrypted user sessions', color: 'text-blue-400' },
  { id: 5, name: 'Bot Tokens', desc: 'Encrypted clone bot tokens', color: 'text-purple-400' },
  { id: 7, name: 'Media Cache', desc: 'Temporary media storage', color: 'text-green-400' },
  { id: 9, name: 'Activity Logs', desc: 'All bot activity logs', color: 'text-orange-400' },
  { id: 0, name: 'Per-User Topics', desc: 'Individual user tracking', color: 'text-pink-400' },
];

export default function Architecture() {
  return (
    <section className="relative py-24 lg:py-32">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-success/30 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-success/10 border border-success/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-success" />
            <span className="text-sm font-medium text-success">Zero Server Costs</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">Architecture</span>
          </h2>
          <p className="text-text-dim max-w-2xl mx-auto text-lg">
            Uses Telegram Supergroup as database — no external servers, databases, or storage needed.
            Host on your local device or any cloud server.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Flow diagram */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="bg-card border border-border rounded-2xl p-8"
          >
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Server className="w-5 h-5 text-primary-light" />
              Data Flow
            </h3>

            <div className="space-y-4">
              {[
                { from: '👤 User', action: 'sends link', to: '🤖 Bot', color: 'border-blue-500/30' },
                { from: '🤖 Bot', action: 'downloads from', to: '🔒 Private Source', color: 'border-purple-500/30' },
                { from: '🤖 Bot', action: 'saves to', to: '💾 Supergroup DB', color: 'border-green-500/30' },
                { from: '🤖 Bot', action: 'forwards to', to: '📤 Destination', color: 'border-teal-500/30' },
                { from: '🤖 Bot', action: 'logs activity', to: '📋 User Topic', color: 'border-orange-500/30' },
              ].map((flow, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className={`flex items-center gap-3 p-3 bg-darker/50 border ${flow.color} rounded-xl`}
                >
                  <span className="text-sm font-semibold text-white whitespace-nowrap">{flow.from}</span>
                  <div className="flex-1 flex items-center gap-2">
                    <div className="flex-1 h-px bg-border" />
                    <span className="text-xs text-text-dim whitespace-nowrap">{flow.action}</span>
                    <ArrowRight className="w-3 h-3 text-text-dim" />
                  </div>
                  <span className="text-sm font-semibold text-white whitespace-nowrap">{flow.to}</span>
                </motion.div>
              ))}
            </div>

            {/* Hosting options */}
            <div className="mt-6 p-4 bg-darker/80 border border-border rounded-xl">
              <h4 className="text-sm font-bold text-text-dim mb-3">Hosting Options</h4>
              <div className="flex gap-3">
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="flex-1 flex items-center gap-2 p-3 bg-card border border-border rounded-xl"
                >
                  <Smartphone className="w-5 h-5 text-primary-light" />
                  <div>
                    <p className="text-xs font-semibold text-white">Local Device</p>
                    <p className="text-[10px] text-text-dim">Run main.py</p>
                  </div>
                </motion.div>
                <motion.div
                  whileHover={{ scale: 1.05 }}
                  className="flex-1 flex items-center gap-2 p-3 bg-card border border-border rounded-xl"
                >
                  <Cloud className="w-5 h-5 text-accent" />
                  <div>
                    <p className="text-xs font-semibold text-white">Cloud Server</p>
                    <p className="text-[10px] text-text-dim">Any VPS/hosting</p>
                  </div>
                </motion.div>
              </div>
            </div>
          </motion.div>

          {/* Supergroup topics */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <div className="bg-card border border-border rounded-2xl p-8">
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                <Database className="w-5 h-5 text-success" />
                Supergroup Database Topics
              </h3>

              <div className="space-y-3">
                {topicList.map((topic, i) => (
                  <motion.div
                    key={topic.id}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    whileHover={{ x: 4 }}
                    className="flex items-center gap-4 p-4 bg-darker/50 border border-border/50 rounded-xl hover:border-border transition-all"
                  >
                    <div className={`text-2xl font-black ${topic.color}`}>
                      #{topic.id || '∗'}
                    </div>
                    <div className="flex-1">
                      <h4 className="text-sm font-semibold text-white">{topic.name}</h4>
                      <p className="text-xs text-text-dim">{topic.desc}</p>
                    </div>
                    <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Encryption info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 }}
              className="mt-6 bg-card border border-primary/20 rounded-2xl p-6"
            >
              <div className="flex items-start gap-4">
                <Shield className="w-8 h-8 text-primary-light shrink-0" />
                <div>
                  <h4 className="text-sm font-bold text-white mb-2">Fernet Encryption</h4>
                  <p className="text-xs text-text-dim leading-relaxed">
                    All sessions, bot tokens, and sensitive data are encrypted using 
                    Fernet symmetric encryption (32-byte key) before being stored in 
                    the supergroup topics. Even if someone accesses the group, the data 
                    remains unreadable.
                  </p>
                  <div className="mt-3 p-2 bg-darker rounded-lg">
                    <code className="text-[11px] text-accent font-mono break-all">
                      ENCRYPTION_KEY = "d_is1s1kjBRTHXXVt..."
                    </code>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
