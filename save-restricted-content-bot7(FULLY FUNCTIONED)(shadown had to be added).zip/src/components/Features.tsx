import { memo } from 'react';
import { motion } from 'framer-motion';
import {
  LogIn, Globe, Link2, Layers, Forward, Type,
  Bot, ShieldCheck, Users,
  Smartphone, Key, Timer, Sparkles, Pin, StopCircle
} from 'lucide-react';

const featureCategories = [
  {
    title: 'Login Methods',
    icon: LogIn,
    color: 'from-blue-500 to-cyan-500',
    borderColor: 'border-blue-500/30',
    features: [
      'Login using your mobile number',
      'Login using Pyrogram/Telethon session',
      'Session & login info is encrypted for safety',
      'Invite link not needed',
    ],
  },
  {
    title: 'Where Bot Supported',
    icon: Globe,
    color: 'from-green-500 to-emerald-500',
    borderColor: 'border-green-500/30',
    features: [
      'Private channel supported',
      'Private groups supported',
      'Super group/topic supported',
      'Restricted bot supported',
    ],
  },
  {
    title: 'Single Link Mode',
    icon: Link2,
    color: 'from-purple-500 to-pink-500',
    borderColor: 'border-purple-500/30',
    features: [
      'Single link allowed',
      '/single processes one link at a time',
      'After completion notify you',
      'Real-time progress tracking',
    ],
  },
  {
    title: 'Batch Mode + Controls',
    icon: Layers,
    color: 'from-orange-500 to-red-500',
    borderColor: 'border-orange-500/30',
    features: [
      '/batch unlimited at a time',
      '🛑 Stop batch with inline button',
      'Timer to avoid flood wait',
      'After batch completion notify you',
    ],
  },
  {
    title: 'Channel Forwarding',
    icon: Forward,
    color: 'from-teal-500 to-cyan-500',
    borderColor: 'border-teal-500/30',
    features: [
      'Forward directly into your channel/group',
      'Super group topic forwarding supported',
      'Set custom destination per user',
      'Automatic forwarding after download',
    ],
  },
  {
    title: 'Caption Modification',
    icon: Type,
    color: 'from-yellow-500 to-amber-500',
    borderColor: 'border-yellow-500/30',
    features: [
      '2 Replace words with inline delete buttons',
      '2 Delete words with inline delete buttons',
      '2 Spoiler effects with inline buttons',
      'Add prefix/suffix, hyperlinks, quotes',
    ],
  },
  {
    title: 'Auto-Pin Detection',
    icon: Pin,
    color: 'from-pink-500 to-rose-500',
    borderColor: 'border-pink-500/30',
    features: [
      'Detects pinned messages in source',
      'Auto-pins in destination channel',
      'Works with super group topics',
      'Multiple pins supported',
    ],
  },
  {
    title: 'Clone Bot',
    icon: Bot,
    color: 'from-indigo-500 to-violet-500',
    borderColor: 'border-indigo-500/30',
    features: [
      'Add your bot token to upload media',
      'Prevents 80% flooding',
      'Bot token encrypted for safety',
      'Seamless integration',
    ],
  },
  {
    title: 'Batch Controls',
    icon: StopCircle,
    color: 'from-red-500 to-pink-500',
    borderColor: 'border-red-500/30',
    features: [
      '▶️ Start batch with inline button',
      '⏸️ Pause/Resume batch anytime',
      '🛑 Stop batch immediately',
      'Progress shown for each file',
    ],
  },
  {
    title: 'Progress Tracking',
    icon: Timer,
    color: 'from-lime-500 to-green-500',
    borderColor: 'border-lime-500/30',
    features: [
      'Individual file progress display',
      'Download speed indicator (MB/s)',
      'Percentage completed per file',
      'Estimated time remaining (ETA)',
    ],
  },
  {
    title: 'Security & Encryption',
    icon: ShieldCheck,
    color: 'from-cyan-500 to-blue-500',
    borderColor: 'border-cyan-500/30',
    features: [
      'Fernet encryption for stored sessions',
      'Bot tokens encrypted at rest',
      'Per-user isolated data storage',
      'Activity logging & monitoring',
    ],
  },
  {
    title: 'Multi-User System',
    icon: Users,
    color: 'from-sky-500 to-blue-500',
    borderColor: 'border-sky-500/30',
    features: [
      'Multi-user support with queue system',
      'One task at a time per safety',
      'Individual topic tracking per user',
      'Premium membership system',
    ],
  },
  {
    title: 'Admin Panel',
    icon: Key,
    color: 'from-fuchsia-500 to-purple-500',
    borderColor: 'border-fuchsia-500/30',
    features: [
      'Set UPI ID & Razorpay integration',
      'Give premium & promocodes',
      'Ban users & manage plans',
      'Set welcome message/image/video',
    ],
  },
  {
    title: 'Hosting Flexibility',
    icon: Smartphone,
    color: 'from-emerald-500 to-teal-500',
    borderColor: 'border-emerald-500/30',
    features: [
      'Host on local device or any server',
      'Uses Telegram supergroup as database',
      'No external DB server needed',
      'Run main.py to start anywhere',
    ],
  },
];

const Features = memo(function Features() {
  return (
    <section id="features" className="relative py-20 lg:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4 }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-primary/10 border border-primary/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-primary-light" />
            <span className="text-sm font-medium text-primary-light">Packed with Power</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">All Features</span>
          </h2>
          <p className="text-text-dim max-w-xl mx-auto text-lg">
            Everything you need to save, modify, and forward restricted Telegram content.
          </p>
        </motion.div>

        {/* Feature grid - optimized with simpler animations */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {featureCategories.map((cat, i) => {
            const Icon = cat.icon;
            return (
              <motion.div
                key={cat.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.3, delay: Math.min(i * 0.05, 0.3) }}
                className={`group relative bg-card/80 border ${cat.borderColor} rounded-2xl p-5 hover:bg-card-hover transition-all duration-200 hover:-translate-y-1`}
              >
                {/* Icon */}
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${cat.color} flex items-center justify-center mb-4 shadow-lg`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>

                {/* Title */}
                <h3 className="text-base font-bold text-white mb-3">{cat.title}</h3>

                {/* Features */}
                <ul className="space-y-1.5">
                  {cat.features.map((f) => (
                    <li key={f} className="flex items-start gap-2 text-xs text-text-dim">
                      <span className="text-success mt-0.5 shrink-0">✓</span>
                      <span>{f}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
});

export default Features;
