import { memo } from 'react';
import { motion } from 'framer-motion';
import { UserPlus, Link2, Download, Forward, CheckCircle, Sparkles, StopCircle, Pin } from 'lucide-react';

const steps = [
  {
    step: '01',
    title: 'Login & Authenticate',
    desc: 'Start the bot and login with your mobile number or Pyrogram/Telethon session. Your session is encrypted with Fernet encryption.',
    icon: UserPlus,
    color: 'from-blue-500 to-cyan-500',
  },
  {
    step: '02',
    title: 'Set Destination',
    desc: 'Configure your destination channel, group, or super group topic where content will be forwarded automatically.',
    icon: Forward,
    color: 'from-purple-500 to-pink-500',
  },
  {
    step: '03',
    title: 'Send Link(s) & Control',
    desc: 'Send /single or /batch with links. Use inline buttons to ⏸️ Pause, ▶️ Resume, or 🛑 Stop the batch anytime.',
    icon: Link2,
    color: 'from-orange-500 to-red-500',
    highlight: true,
  },
  {
    step: '04',
    title: 'Watch Progress per File',
    desc: 'Each file shows individual progress: speed (MB/s), percentage (%), estimated time (ETA), and file name.',
    icon: Download,
    color: 'from-green-500 to-emerald-500',
  },
  {
    step: '05',
    title: 'Auto Forward & Pin',
    desc: 'Content forwarded to destination. Pinned messages are auto-pinned in your channel. Caption modifications applied.',
    icon: Pin,
    color: 'from-amber-500 to-orange-500',
    highlight: true,
  },
  {
    step: '06',
    title: 'Completion Notification',
    desc: 'Get notified with full stats: files completed, time taken, pinned messages, and any errors encountered.',
    icon: CheckCircle,
    color: 'from-teal-500 to-cyan-500',
  },
];

const HowItWorks = memo(function HowItWorks() {
  return (
    <section id="how-it-works" className="relative py-20 lg:py-28 overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/30 to-transparent" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4 }}
          className="text-center mb-16"
        >
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-accent/10 border border-accent/20 rounded-full mb-4">
            <Sparkles className="w-4 h-4 text-accent" />
            <span className="text-sm font-medium text-accent">Simple Process</span>
          </div>
          <h2 className="text-4xl lg:text-5xl font-black mb-4">
            <span className="gradient-text">How It Works</span>
          </h2>
          <p className="text-text-dim max-w-xl mx-auto text-lg">
            Six simple steps to save any restricted content
          </p>
        </motion.div>

        {/* Steps grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.step}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-30px' }}
                transition={{ duration: 0.3, delay: Math.min(i * 0.08, 0.3) }}
                className={`relative p-6 bg-card/80 border rounded-2xl hover:bg-card-hover transition-all duration-200 ${
                  step.highlight ? 'border-warning/40' : 'border-border/50'
                }`}
              >
                {/* Step number */}
                <span className="absolute top-4 right-4 text-4xl font-black text-border/30">
                  {step.step}
                </span>

                {/* Icon */}
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center mb-4 shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-lg font-bold text-white mb-2">{step.title}</h3>
                <p className="text-sm text-text-dim leading-relaxed">{step.desc}</p>

                {/* Highlight badge */}
                {step.highlight && (
                  <div className="absolute -top-2 -right-2 px-2 py-0.5 bg-warning text-darker text-[10px] font-bold rounded-full">
                    NEW
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Inline buttons preview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="mt-12 max-w-md mx-auto"
        >
          <p className="text-center text-xs text-text-dim mb-3">Batch Control Inline Buttons</p>
          <div className="bg-telegram/10 border border-telegram/20 rounded-xl p-4">
            <div className="grid grid-cols-3 gap-2">
              <button className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-success/20 border border-success/30 rounded-lg text-success text-xs font-bold">
                ▶️ Resume
              </button>
              <button className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-warning/20 border border-warning/30 rounded-lg text-warning text-xs font-bold">
                ⏸️ Pause
              </button>
              <button className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-danger/20 border border-danger/30 rounded-lg text-danger text-xs font-bold">
                <StopCircle className="w-3.5 h-3.5" />
                Stop
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

export default HowItWorks;
