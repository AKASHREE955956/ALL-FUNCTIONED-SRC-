import { motion } from 'framer-motion';
import {
  Shield, Download, Lock, Zap, Users, Bot,
  Forward, Database, Star, Crown
} from 'lucide-react';

const items = [
  { icon: Shield, text: 'Encrypted Sessions' },
  { icon: Download, text: 'Batch Download' },
  { icon: Lock, text: 'Private Channels' },
  { icon: Zap, text: 'Lightning Fast' },
  { icon: Users, text: 'Multi-User' },
  { icon: Bot, text: 'Clone Bot' },
  { icon: Forward, text: 'Auto Forward' },
  { icon: Database, text: 'Supergroup DB' },
  { icon: Star, text: 'Premium Plans' },
  { icon: Crown, text: 'Admin Panel' },
];

export default function Marquee() {
  const doubled = [...items, ...items];

  return (
    <div className="py-8 border-y border-border/30 bg-card/30 overflow-hidden">
      <motion.div
        className="flex gap-8 whitespace-nowrap"
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 30, repeat: Infinity, ease: 'linear' }}
      >
        {doubled.map((item, i) => {
          const Icon = item.icon;
          return (
            <div
              key={`${item.text}-${i}`}
              className="flex items-center gap-2 px-6 py-2 bg-darker/50 border border-border/30 rounded-full shrink-0"
            >
              <Icon className="w-4 h-4 text-primary-light" />
              <span className="text-sm font-medium text-text-dim">{item.text}</span>
            </div>
          );
        })}
      </motion.div>
    </div>
  );
}
