import { lazy, Suspense, memo } from 'react';

// Eager load critical above-fold components
import Particles from './components/Particles';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Marquee from './components/Marquee';

// Lazy load below-fold components for faster initial load
const Features = lazy(() => import('./components/Features'));
const HowItWorks = lazy(() => import('./components/HowItWorks'));
const ProgressDemo = lazy(() => import('./components/ProgressDemo'));
const PinnedFeature = lazy(() => import('./components/PinnedFeature'));
const CaptionEditor = lazy(() => import('./components/CaptionEditor'));
const Demo = lazy(() => import('./components/Demo'));
const AdminPanel = lazy(() => import('./components/AdminPanel'));
const Architecture = lazy(() => import('./components/Architecture'));
const Commands = lazy(() => import('./components/Commands'));
const Pricing = lazy(() => import('./components/Pricing'));
const Footer = lazy(() => import('./components/Footer'));

// Simple loading fallback
const LoadingFallback = memo(function LoadingFallback() {
  return (
    <div className="py-20 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
    </div>
  );
});

export default function App() {
  return (
    <div className="animated-bg min-h-screen relative">
      <Particles />
      <Navbar />
      <main className="relative z-10">
        <Hero />
        <Marquee />
        <Suspense fallback={<LoadingFallback />}>
          <Features />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <HowItWorks />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <ProgressDemo />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <PinnedFeature />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <CaptionEditor />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <Demo />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <AdminPanel />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <Architecture />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <Commands />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <Pricing />
        </Suspense>
        <Suspense fallback={<LoadingFallback />}>
          <Footer />
        </Suspense>
      </main>
    </div>
  );
}
